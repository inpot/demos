
package com.tct.android.tctgamerecorder;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.tct.android.tctgamerecorder.util.PermissionUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Dummy activity, just to start RecordService
 * 
 * @author 93372
 */
public class MainActivity extends Activity {

    private Handler handler;
    private List<String> deniedPermissions;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Log.e("Kaidi", "MainActivity on create, check and request permission.");
        boolean isDone = PermissionUtil.checkAndRequestPermissionsIsDone(this,
                PermissionUtil.IntegrantPermissions, PermissionUtil.CHECK_REQUEST_PERMISSION_RESULT);
        //if all the permission is granted, Start record system direct .
        // if not , checkAndRequestPermissionsIsDone() will request not granted permissions.
        if(isDone) {
            Log.i("Kaidi", " on create -> directly start service. is done:" + isDone);
            startRecordService();
        }
    }

    private void startRecordService(){
        handler = new Handler();
        handler.post(new Runnable() {
            public void run() {
                Log.e("Kaidi", "in runnable");
                Intent intent = new Intent(MainActivity.this, RecordService.class);
                startService(intent);
                finish();
            }
        });
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.i("mylog", "onRequestPermissionsResult-> requestcode:" + requestCode);
        if(requestCode == PermissionUtil.CHECK_REQUEST_PERMISSION_RESULT) {
            boolean isAllPermissionGrant = true;
            for(int i=0; i < grantResults.length; i++) {
                if( grantResults[i] == PackageManager.PERMISSION_DENIED){
                    if(deniedPermissions == null){
                        deniedPermissions = new ArrayList<String>();
                    }
                    isAllPermissionGrant = false;
                    if(i < permissions.length){
                        deniedPermissions.add(permissions[i]);
                    }
                }
            }
            if(isAllPermissionGrant){
                Log.i("mylog", "onRequestPermissionsResult-> start service");
                startRecordService();
            }else{
                Toast.makeText(this, this.getString(R.string.permission_notify_requirement_deny),
                        Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }
}
