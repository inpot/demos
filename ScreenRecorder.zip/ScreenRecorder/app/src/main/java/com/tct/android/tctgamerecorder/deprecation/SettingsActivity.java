
package com.tct.android.tctgamerecorder.deprecation;

import java.io.File;
import java.util.List;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.AnimationDrawable;
import android.hardware.Camera;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera.Size;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.PreferenceActivity;
import android.support.v4.app.NotificationCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.TextureView;
import android.view.TextureView.SurfaceTextureListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLayoutChangeListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.tct.android.tctgamerecorder.layout.MyRelativeLayout;
import com.tct.android.tctgamerecorder.R;
import com.tct.android.tctgamerecorder.util.CameraHelper;
import com.tct.android.tctgamerecorder.util.RecorderUtil;
import com.tct.android.tctgamerecorder.util.RecorderUtil.Resolution;

@SuppressWarnings("deprecation")
public class SettingsActivity extends PreferenceActivity {

    private final static String TAG = "SettingsActivity";
    // For Preference controls
    private CheckBoxPreference statusPref;
    private CheckBoxPreference frontCameraPref;
    private ListPreference audioPref;
    private ListPreference videoSizePref;
    private ListPreference videoQualityPref;

    // For screen record
    private NotificationManager nm;
    private MediaProjectionManager mProjectionManager;
    private MediaProjection mMediaProjection;
    private final static int PERMISSION_CODE = 1;
    private RecorderUtil mRecorderUtil;
    private int mScreenDensity;
    private VirtualDisplay mVirtualDisplay;

    // For broadcast & keys
    public final static String KEY_HIDE = "com.tct.android.tctgamerecorder.key_hide";
    public final static String KEY_ACTION = "com.tct.android.tctgamerecorder.key_action";
    public final static String ACTION_START = "start";
    public final static String ACTION_STOP = "stop";
    public BroadcastReceiver mBroadcastReceiver;

    // For floating UI
    private LayoutInflater mLayoutInflater;
    private WindowManager windowManager;
    private WindowManager.LayoutParams wmParams;
    private MyRelativeLayout mContainer;
    private TextView mRecordView;
    private TextureView mTextureView;
    private Camera mCamera;
    private Handler mHandler;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        mLayoutInflater = LayoutInflater.from(this);
        mHandler = new Handler();
        this.addPreferencesFromResource(R.xml.settings);
        // Find Preference objects
        statusPref = (CheckBoxPreference) this
                .findPreference(getString(R.string.key_status));
        frontCameraPref = (CheckBoxPreference) this
                .findPreference(getString(R.string.key_front_camera));
        audioPref = (ListPreference) this
                .findPreference(getString(R.string.key_audio_settings));
        videoSizePref = (ListPreference) this
                .findPreference(getString(R.string.key_video_size));
        videoQualityPref = (ListPreference) this
                .findPreference(getString(R.string.key_video_quality));

        statusPref
                .setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
                    @Override
                    public boolean onPreferenceChange(Preference pref,
                            Object value) {
                        Log.i(TAG, "Status : " + value.toString());
                        if (Boolean.TRUE.equals(value)) {
                            showFloatingView();
                        } else {
                            hideFloatingView();
                        }
                        return true;
                    }
                });

        // Notify user that it will be applied to next recording
        OnPreferenceChangeListener listener = new OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference,
                    Object value) {
                Toast.makeText(SettingsActivity.this, R.string.msg_apply,
                        Toast.LENGTH_SHORT).show();
                return true;
            }
        };
        frontCameraPref.setOnPreferenceChangeListener(listener);
        audioPref.setOnPreferenceChangeListener(listener);
        videoSizePref.setOnPreferenceChangeListener(listener);
        videoQualityPref.setOnPreferenceChangeListener(listener);

        // Initialize media projection
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mRecorderUtil = new RecorderUtil();
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        mScreenDensity = metrics.densityDpi;
        windowManager = (WindowManager) getApplicationContext()
                .getSystemService(Context.WINDOW_SERVICE);

        IntentFilter filter = new IntentFilter(KEY_ACTION);
        mBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getExtras().getString(KEY_ACTION);
                if (ACTION_START.equals(action)) {
                    tryShareScreen();
                } else if (ACTION_STOP.equals(action)) {
                    stopRecord();
                }
            }
        };
        this.registerReceiver(mBroadcastReceiver, filter);

        boolean needHide = getIntent().getBooleanExtra(KEY_HIDE, false);
        if (needHide)
            this.moveTaskToBack(true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mMediaProjection != null) {
            mMediaProjection.stop();
            mMediaProjection = null;
        }
        this.unregisterReceiver(mBroadcastReceiver);
    }

    private void tryShareScreen() {
        if (mMediaProjection == null) {
            startActivityForResult(
                    mProjectionManager.createScreenCaptureIntent(),
                    PERMISSION_CODE);
            return;
        }
        startRecord();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != PERMISSION_CODE) {
            Log.e(TAG, "Unknown request code: " + requestCode);
            return;
        }
        if (resultCode != RESULT_OK) {
            Toast.makeText(this, "Screen Cast Permission Denied",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        mMediaProjection = mProjectionManager.getMediaProjection(resultCode,
                data);
        startRecord();
    }

    private void startRecord() {
        Log.i("Kaidi", "Start Record");
        mRecorderUtil.initAndPrepare(this);
        Resolution res = mRecorderUtil.getVideoSize(this);
        Surface surface = mRecorderUtil.getSurface();
        mVirtualDisplay = createVirtualDisplay(res, surface);
        mRecorderUtil.start();
    }

    private void stopRecord() {
        Log.i("Kaidi", "Stop Record");
        mRecorderUtil.stop(this);
        if (mVirtualDisplay == null)
            return;
        mVirtualDisplay.release();
        mVirtualDisplay = null;
    }

    private VirtualDisplay createVirtualDisplay(Resolution res, Surface surface) {
        return mMediaProjection.createVirtualDisplay("MainActivity", res.width,
                res.height, mScreenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null,
                null);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    /**
     * show floating view
     */
    private void showFloatingView() {
        wmParams = new WindowManager.LayoutParams();
        wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        wmParams.format = PixelFormat.RGBA_8888;
        wmParams.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
                | LayoutParams.FLAG_NOT_FOCUSABLE;

        wmParams.gravity = Gravity.START | Gravity.TOP;
        wmParams.x = 0;
        wmParams.y = 0;
        wmParams.width = 160;
        wmParams.height = 160;

        mContainer = (MyRelativeLayout) mLayoutInflater.inflate(
                R.layout.comp_floating_texture, null);
        mRecordView = (TextView) mContainer.findViewById(R.id.RecordView);
        mTextureView = (TextureView) mContainer.findViewById(R.id.TextureView);
        mTextureView.addOnLayoutChangeListener(new OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View arg0, int arg1, int arg2, int arg3, int arg4, int arg5,
                    int arg6, int arg7, int arg8) {
                // TODO transform
            }
        });
        // mContainer.set(windowManager, wmParams);

        mRecordView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                tryShareScreen();
                mRecordView.setBackgroundResource(R.drawable.boost);
                mRecordView.setText("");
                AnimationDrawable ad = (AnimationDrawable) mRecordView.getBackground();
                ad.start();

                mHandler.postDelayed(new Runnable() {
                    public void run() {
                        mRecordView.setVisibility(View.GONE);
                        mTextureView.setVisibility(View.VISIBLE);
                    }
                }, 1800);
            }
        });

        mTextureView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                stopAndNotify();
            }
        });

        mTextureView.setSurfaceTextureListener(new SurfaceTextureListener() {

            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture texture,
                    int arg1, int arg2) {
                Log.i("Kaidi", "Surface Created");
                mCamera = CameraHelper.getDefaultFrontFacingCameraInstance();
                mCamera.setDisplayOrientation(90);
                Parameters ps = mCamera.getParameters();
                // ps.setPictureFormat(PixelFormat.JPEG);
                // ps.setPictureSize(160, 160);
                // Use lowest fps
                List<Integer> fpsList = ps.getSupportedPreviewFrameRates();
                int fps = -1;
                for (int f : fpsList) {
                    if (fps < 0 || f < fps)
                        fps = f;
                }
                if (fps > 0)
                    ps.setPreviewFrameRate(fps);

                // Calculate preview size
                List<Size> list = ps.getSupportedPreviewSizes();
                int w = -1;
                int h = -1;
                for (Size size : list) {
                    if (w < 0 || (w > 0 && w > size.width)) {
                        w = size.width;
                        h = size.height;
                    }
                }
                if (w > 0)
                    ps.setPreviewSize(w, h);
                ps.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
                mCamera.setParameters(ps);
                mCamera.setPreviewCallback(new PreviewCallback() {
                    @Override
                    public void onPreviewFrame(byte[] arg0, Camera arg1) {
                        Log.i("Kaidi", "one frame");
                    }
                });
                try {
                    // mCamera.setPreviewDisplay(mSurfaceView.getHolder());
                    mCamera.setPreviewTexture(texture);
                    mCamera.startPreview();
                } catch (Exception e) {
                    Log.e("Kaidi", "Preview failed", e);
                }
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture arg0) {
                stopPreview();
                return false;
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture arg0,
                    int arg1, int arg2) {

            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture arg0) {
            }

        });

        windowManager.addView(mContainer, wmParams);
    }

    private void stopAndNotify() {
        stopRecord();
        mTextureView.setVisibility(View.GONE);
        mRecordView.setText(R.string.record);
        mRecordView.setBackgroundResource(R.drawable.gc_icon_rec);
        mRecordView.setVisibility(View.VISIBLE);

        String filename = mRecorderUtil.getFilename();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                SettingsActivity.this);
        builder.setSmallIcon(R.drawable.ic_launcher);
        builder.setTicker(getString(R.string.noti_finished));
        builder.setWhen(System.currentTimeMillis());
        builder.setAutoCancel(true);
        CharSequence contentTitle = getString(R.string.noti_finished);
        CharSequence contentText = getString(R.string.noti_open) + " "
                + filename;
        builder.setContentTitle(contentTitle);
        builder.setContentText(contentText);
        builder.setPriority(Notification.PRIORITY_MAX);
        Intent fullscreenIntent = new Intent();
        builder.setFullScreenIntent(PendingIntent.getBroadcast(
                SettingsActivity.this, 0, fullscreenIntent, 0), true);

        // Content Item to open the video
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("oneshot", 0);
        intent.putExtra("configchange", 0);
        Log.i("Kaidi", "Filename : " + filename);
        Uri uri = Uri.fromFile(new File(filename));
        intent.setDataAndType(uri, "video/*");
        PendingIntent contentIntent = PendingIntent.getActivity(
                SettingsActivity.this, 0, intent, 0);
        builder.setContentIntent(contentIntent);

        builder.addAction(R.drawable.ic_share,
                getString(R.string.noti_action_share), null);
        builder.addAction(R.drawable.ic_delete,
                getString(R.string.noti_action_delete), null);
        builder.addAction(R.drawable.ic_cut,
                getString(R.string.noti_action_trim), null);

        try {
            nm.cancel(1);
        } catch (Exception e) {
            Log.e("Kaidi", "Failed to cancel", e);
        }
        nm.notify(1, builder.build());
    }

    private void stopPreview() {
        if (mCamera != null) {
            try {
                mCamera.stopPreview();
                mCamera.release();
                mCamera = null;
            } catch (Exception e) {
                Log.e("Kaidi", "Release failed", e);
            }
        }
    }

    /**
     * hide floating view
     */
    private void hideFloatingView() {
        if (mTextureView != null && mTextureView.getVisibility() == View.VISIBLE) {
            try {
                if (mCamera != null)
                    mCamera.setPreviewCallback(null);
                stopAndNotify();
            } finally {
            }
        }
        if (mContainer != null) {
            try {
                windowManager.removeView(mContainer);
            } catch (Exception e) {
                Log.e("Kaidi", "Failed to remove view", e);
            }
        }
    }
}
