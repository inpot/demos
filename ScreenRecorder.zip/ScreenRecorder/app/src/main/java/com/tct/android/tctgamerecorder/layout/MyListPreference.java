
package com.tct.android.tctgamerecorder.layout;

import android.content.Context;
import android.preference.ListPreference;
import android.util.AttributeSet;

/**
 * Will change summary according to selection
 * 
 * @author 93372
 */
public class MyListPreference extends ListPreference {
    public MyListPreference(final Context context) {
        this(context, null);
    }

    public MyListPreference(final Context context, final AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void setValue(String value) {
        super.setValue(value);
        setSummary(value);
    }

    @Override
    public void setSummary(CharSequence summary) {
        super.setSummary(getEntry());
    }
}
