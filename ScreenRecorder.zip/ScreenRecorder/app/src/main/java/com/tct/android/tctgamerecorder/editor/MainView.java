
package com.tct.android.tctgamerecorder.editor;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.util.Log;
import android.view.SurfaceHolder;

public class MainView extends GLSurfaceView {
    MainRenderer mRenderer;

    public MainView(Context context) {
        super(context);
        mRenderer = new MainRenderer(this);
        setEGLContextClientVersion(2);
        setRenderer(mRenderer);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
    }

    public void surfaceCreated(SurfaceHolder holder) {
        Log.e("Kaidi", "Surface Created");
        super.surfaceCreated(holder);
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.e("Kaidi", "Surface Destroy");
        mRenderer.close();
        super.surfaceDestroyed(holder);
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        Log.e("Kaidi", "Surface Changed");
        super.surfaceChanged(holder, format, w, h);
    }
}
