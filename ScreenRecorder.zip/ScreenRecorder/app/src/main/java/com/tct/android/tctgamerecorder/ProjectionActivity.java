
package com.tct.android.tctgamerecorder;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;

public class ProjectionActivity extends Activity {

    private final static int REQUEST_CODE = 100;
    private MediaProjectionManager mProjectionManager;
    private MediaProjection mMediaProjection;
    private boolean mGetResult = false;

    private BroadcastReceiver mPorjectionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String command = intent.getStringExtra(RecordService.KEY_COMMAND);
            if (RecordService.COMMMAN_FINISH_PROJECTION_ACTIVITY.equals(command)) {
                ProjectionActivity.this.finishActivity(REQUEST_CODE);
                ProjectionActivity.this.finish();
            } else if (RecordService.COMMAND_PERMISSION_ACTIVITY_STOP.equals(command)) {
                if (mGetResult == false) {
                    Intent it = new Intent(RecordService.ACTION);
                    it.putExtra(RecordService.KEY_COMMAND,
                            RecordService.COMMAND_CANCEL);
                    sendBroadcast(it);
                    ProjectionActivity.this.finishActivity(REQUEST_CODE);
                }
            }
        }
    };

    //modified by yangyang2@tcl.com, fix bug 1305216 begin
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        mGetResult = false;
//        if (getIntent() != null) {
//            mProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
//            startActivityForResult(
//                    mProjectionManager
//                            .createScreenCaptureIntent(),
//                    REQUEST_CODE);
//        }
        IntentFilter filter = new IntentFilter(RecordService.ACTION);
        this.registerReceiver(mPorjectionReceiver, filter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (getIntent() != null) {
            mGetResult = false;
            mProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            startActivityForResult(
                    mProjectionManager
                            .createScreenCaptureIntent(),
                    REQUEST_CODE);
        }
    }
    //modified by yangyang2@tcl.com, fix bug 1305216 end

    @Override
    protected void onDestroy() {
        super.onDestroy();
        this.unregisterReceiver(mPorjectionReceiver);
    }

    @Override
    public void onActivityResult(int requestCode,
                                 int resultCode, Intent intent) {
        mGetResult = true;
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                mMediaProjection = mProjectionManager
                        .getMediaProjection(resultCode,
                                intent);
                RecordService.setMP(mMediaProjection);
                Intent it = new Intent(RecordService.ACTION);
                it.putExtra(RecordService.KEY_COMMAND,
                        RecordService.COMMAND_START);
                sendBroadcast(it);
            } else {
                Intent it = new Intent(RecordService.ACTION);
                it.putExtra(RecordService.KEY_COMMAND,
                        RecordService.COMMAND_CANCEL);
                sendBroadcast(it);
            }
        }
        finish();
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void onConfigurationChanged(
            Configuration paramConfiguration) {
        super.onConfigurationChanged(paramConfiguration);
    }
}
