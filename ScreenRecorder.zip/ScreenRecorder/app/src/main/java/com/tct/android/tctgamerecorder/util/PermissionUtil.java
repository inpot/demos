package com.tct.android.tctgamerecorder.util;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.PermissionChecker;

import java.util.ArrayList;
import java.util.List;

public class PermissionUtil {
    public static String[] IntegrantPermissions = new String[]{
            Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
    };
    //Default result to {@link OnRequestPermissionsResultCallback#onRequestPermissionsResult(int, String[], int[])}.
    public static final int CHECK_REQUEST_PERMISSION_RESULT = 3;

    /*
     * @param activity The target activity.
     * @param permissions The requested permissions.
     * @param requestCode Application specific request code to match with a result
     *    reported to {@link OnRequestPermissionsResultCallback#onRequestPermissionsResult(
     *    int, String[], int[])}.
     */
    public static boolean checkAndRequestPermissionsIsDone(final @NonNull Activity activity,
                                          final @NonNull String[] permissions, final int requestCode){
        List<String> requestList = new ArrayList<>();
        for(String perm : permissions){
            if(PermissionChecker.checkSelfPermission(activity, perm) != PackageManager.PERMISSION_GRANTED){
                requestList.add(perm);
            }
        }

        if(requestList.size() > 0){
            ActivityCompat.requestPermissions(activity, requestList.toArray(new String[requestList.size()]), requestCode);
            return false;
        }
        return true;
    }

    public static boolean checkPermissionIsAllGranted(Context context,
                                                             final @NonNull String[] permissions){
        boolean isAllDone = true;
        for(String perm : permissions){
            if(PermissionChecker.checkSelfPermission(context, perm) != PackageManager.PERMISSION_GRANTED){
                isAllDone = false;
                break;
            }
        }
        return isAllDone;
    }

}


