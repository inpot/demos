
package com.tct.android.tctgamerecorder.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.tct.android.tctgamerecorder.R;

public class SettingsUtil {

    private final static int DEFAULT_LENGTH = 180;
    private final static String KEY_FIRST_RUN = "key_screen_recorder_first_run";

    public final static int SCREEN_SIZE_SMALL = 0;
    public final static int SCREEN_SIZE_LARGE = 1;
    public final static int SCREEN_SIZE_FULL_SCREEN = 2;

    /**
     * Get SharedPreference
     * 
     * @param context
     * @return
     */
    private static SharedPreferences getSps(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static boolean isScreenRecordOn(Context context) {
        SharedPreferences sps = getSps(context);
        return sps.getBoolean(context.getString(R.string.key_status), false);
    }

    public static void setScreenRecordOn(Context context, boolean b) {
        SharedPreferences sps = getSps(context);
        sps.edit().putBoolean(context.getString(R.string.key_status), b).commit();
    }

    public static boolean usingFrontCamera(Context context) {
        SharedPreferences sps = getSps(context);
        return sps.getBoolean(context.getString(R.string.key_front_camera), true);
    }

    public static void setFrontCamera(Context context, boolean b) {
        SharedPreferences sps = getSps(context);
        sps.edit().putBoolean(context.getString(R.string.key_front_camera), b).commit();
    }

    public static boolean isMicrophoneOn(Context context) {
        SharedPreferences sps = getSps(context);
        return sps.getBoolean(
                context.getString(R.string.key_audio_settings), true);
    }

    // public static int getVideoSize(Context context) {
    // SharedPreferences sps = getSps(context);
    // return Integer.parseInt(sps.getString(
    // context.getString(R.string.key_video_size), "0"));
    // }

    public static int getVideoQuality(Context context) {
        SharedPreferences sps = getSps(context);
        return Integer.parseInt(sps.getString(
                context.getString(R.string.key_video_quality), "0"));
    }

    public static int getX(Context context) {
        SharedPreferences sps = getSps(context);
        return sps.getInt("X", 0);
    }

    public static int getY(Context context) {
        SharedPreferences sps = getSps(context);
        return sps.getInt("Y", 0);
    }

    public static void setXY(Context context, int x, int y) {
        SharedPreferences sps = getSps(context);
        sps.edit().putInt("X", x).putInt("Y", y).commit();
    }

    public static int getLength(Context context) {
        SharedPreferences sps = getSps(context);
        return sps.getInt("Length", DEFAULT_LENGTH);
    }

    public static void setLength(Context context, int length) {
        SharedPreferences sps = getSps(context);
        sps.edit().putInt("Length", length).commit();
    }

    public static int getFrontCameraPreviewPreferenceValue(Context context) {
        SharedPreferences sps = getSps(context);
        int preferenceValue = Integer.parseInt(sps.getString(context.getString(R.string.key_front_camera_preview_size), "0"));
        return preferenceValue;
    }

    public static void setFrontCameraPreviewPreferenceValue(Context context, int val) {
        SharedPreferences sps = getSps(context);
        String str = new String() + val;
        sps.edit().putString(context.getString(R.string.key_front_camera_preview_size), str).commit();
    }

    public static boolean checkScreenRecorderFirstTimeRun(Context context) {
        SharedPreferences sps = getSps(context);
        boolean firstRun = sps.getBoolean(KEY_FIRST_RUN, true);
        if (firstRun == true) {
            sps.edit().putBoolean(KEY_FIRST_RUN, false).commit();
        }
        return firstRun;
    }

    public static boolean getShowTouchesStatus(Context context){
        SharedPreferences sps = getSps(context);
        return  sps.getBoolean(context.getString(R.string.key_preference_showtouches), true);
    }
}
