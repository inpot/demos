
package com.tct.android.tctgamerecorder.layout;

import android.content.Context;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.view.WindowManager;
import android.widget.RelativeLayout;

import com.tct.android.tctgamerecorder.RecordService;
import com.tct.android.tctgamerecorder.util.SettingsUtil;

public class MyRelativeLayout extends RelativeLayout {

    private final static int LENGTH_MIN = 160;
    private final static int LENGTH_MAX = 300;
    private RecordService mRecordService;
    private WindowManager wm;
    private WindowManager.LayoutParams wmParams;
    private int mStatusBarHeight;
    private float mTouchStartX;
    private float mTouchStartY;
    private float x;
    private float y;
    private float nowRawX;
    private float nowRawY;

    private float downRawX;
    private float downRawY;
    private GestureDetector mGestureDetector;
    private ScaleGestureDetector mScaleGestureDetector;
    private boolean hasTwoFingerEvent = false;
    private Vibrator mVibrator;

    public MyRelativeLayout(Context context) {
        super(context);
        initGesturesAndVibrator();
    }

    public MyRelativeLayout(Context context, AttributeSet as) {
        super(context, as);
        initGesturesAndVibrator();
    }

    public MyRelativeLayout(Context context, AttributeSet as, int defStyle) {
        super(context, as, defStyle);
        initGesturesAndVibrator();
    }

    private void initGesturesAndVibrator() {
        mScaleGestureDetector = new ScaleGestureDetector(getContext(),
                new OnScaleGestureListener() {
                    private int downLength;

                    @Override
                    public boolean onScale(ScaleGestureDetector arg0) {
                        float factor = mScaleGestureDetector.getScaleFactor();
                        Log.i("Kaidi", "Current Factor: " + factor);
                        int newLength = (int) ((double) downLength * factor);
                        Log.i("Kaidi", "New Length: " + newLength);
                        updateLength(newLength);
                        return false;
                    }

                    @Override
                    public boolean onScaleBegin(ScaleGestureDetector arg0) {
                        Log.i("Kaidi", "Scale Begin");
                        downLength = wmParams.width;
                        return true;
                    }

                    @Override
                    public void onScaleEnd(ScaleGestureDetector arg0) {
                        float factor = mScaleGestureDetector.getScaleFactor();
                        Log.i("Kaidi", "Current Factor: " + factor);
                        int newLength = (int) ((double) downLength * factor);
                        Log.i("Kaidi", "New Length: " + newLength);
                        updateLength(newLength);
                        SettingsUtil.setLength(getContext(), newLength);
                    }
                });

        mGestureDetector = new GestureDetector(getContext(),
                new OnGestureListener() {

                    private float downX = -1;
                    private float downY = -1;

                    @Override
                    public boolean onDown(MotionEvent event) {
                        // Log.i("Kaidi", "Down");
                        downX = event.getRawX();
                        downY = event.getRawY();
                        return false;
                    }

                    @Override
                    public boolean onFling(MotionEvent arg0, MotionEvent arg1, float arg2,
                            float arg3) {
                        return false;
                    }

                    @Override
                    public void onLongPress(MotionEvent event) {
                        // Log.i("Kaidi", "Long press");
                        float diffX = nowRawX - downX;
                        float diffY = nowRawY - downY;
                        // Log.i("Kaidi", downX + " " + downY + " " + nowRawX +
                        // " " + nowRawY);
                        if (diffX * diffX + diffY * diffY < 25) {
                            mVibrator.vibrate(100);
                            // Intent intent = new Intent(getContext(),
                            // RecordService.class);
                            // getContext().stopService(intent);
                            mRecordService.LongPressStop();
                        }
                    }

                    @Override
                    public boolean onScroll(MotionEvent arg0, MotionEvent arg1, float arg2,
                            float arg3) {
                        return false;
                    }

                    @Override
                    public void onShowPress(MotionEvent arg0) {

                    }

                    @Override
                    public boolean onSingleTapUp(MotionEvent arg0) {
                        // Log.i("Kaidi", "SingleTapUp");
                        return false;
                    }

                });

        mVibrator = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
    }

    public void set(RecordService mRecordService, WindowManager wm,
            WindowManager.LayoutParams params, int mStatusBarHeight) {
        this.mRecordService = mRecordService;
        this.wm = wm;
        this.wmParams = params;
        this.mStatusBarHeight = mStatusBarHeight;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        // Kaidi, Scale detector is not well right not <br>
        // FIXME, should be improved later <br>
        // mGestureDetector.onTouchEvent(event);
        mGestureDetector.onTouchEvent(event);

        if (event.getPointerCount() > 1)
            hasTwoFingerEvent = true;

        nowRawX = event.getRawX();
        nowRawY = event.getRawY();
        x = event.getRawX();
        y = event.getRawY() - mStatusBarHeight;
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                hasTwoFingerEvent = false;
                mTouchStartX = event.getX();
                mTouchStartY = event.getY();
                downRawX = event.getRawX();
                downRawY = event.getRawY();
                // Log.i("Kaidi", "Start " + mTouchStartX + " " + mTouchStartY);
                // Log.i("startP", "startX" + mTouchStartX + "====startY"
                // + mTouchStartY);
                break;

            case MotionEvent.ACTION_MOVE:
                if (!hasTwoFingerEvent)
                    updateViewPosition();
                break;

            case MotionEvent.ACTION_UP:
                if (!hasTwoFingerEvent) {
                    updateViewPosition();

                    // Remember the location
                    SettingsUtil
                            .setXY(getContext(), (int) (x - mTouchStartX), (int) (y - mTouchStartY));
                }
                float xx = event.getRawX();
                float yy = event.getRawY();

                float value = (xx - downRawX) * (xx - downRawX) + (yy - downRawY)
                        * (yy - downRawY);
                mTouchStartX = mTouchStartY = 0;
                if (value > 200)
                    return false;

                break;
        }
        return super.dispatchTouchEvent(event);
    }

    private void updateViewPosition() {

        wmParams.x = (int) (x - mTouchStartX);
        wmParams.y = (int) (y - mTouchStartY);
        wm.updateViewLayout(this, wmParams);
    }

    public void updateViewSize(int width, int height) {
        wmParams.width = width;
        wmParams.height = height;
        wm.updateViewLayout(this, wmParams);
    }

    private void updateLength(int newLength) {
        if (newLength == wmParams.width)
            return;
        if (newLength < LENGTH_MIN)
            newLength = LENGTH_MIN;
        if (newLength > LENGTH_MAX)
            newLength = LENGTH_MAX;

        // Log.i("Kaidi", "Set newlength " + newLength);
        wmParams.width = newLength;
        wmParams.height = newLength;
        wm.updateViewLayout(this, wmParams);
    }
}
