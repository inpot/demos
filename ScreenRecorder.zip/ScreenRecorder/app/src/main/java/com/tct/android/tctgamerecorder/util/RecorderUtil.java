package com.tct.android.tctgamerecorder.util;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import android.content.Context;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.os.Environment;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;
import android.widget.Toast;
import android.net.Uri;

/**
 * Handle MediaRecord logic
 *
 * @author 93372
 */
public class RecorderUtil {

    private final static String TAG = "RecordUtil";
    private MediaRecorder mMediaRecorder;
    private String mFilename;
    private final static String FOLDER_NAME = "ViewMe";
    private final static int VQ_NORMAL = 1 * 1000 * 1000;
    private final static int VQ_FINE = 5 * 1000 * 1000;

    private final static int STATUS_IDLE = 0;
    private final static int STATUS_RECORDING = 1;
    private int status = STATUS_IDLE;
    private Resolution res;
    private Context mContext;
    private static Uri mFileMediaUri;

    public RecorderUtil() {
        mMediaRecorder = new MediaRecorder();
    }

    /**
     * Initialize and prepare MediaRecorder
     *
     * @param context
     */
    public boolean initAndPrepare(Context context) {
        // Make folder if not exist
        if(!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
            Log.e("Kaidi", "Exception : ExternalStorage is not mounted.");
            return false;
        }
        File sdcard = Environment.getExternalStorageDirectory();
        Log.i("Kaidi", "externalStorage path:" + sdcard.getPath());
        File baseDir = new File(sdcard, "DCIM/" + FOLDER_NAME);
        if (!baseDir.exists())
            baseDir.mkdirs();
        // Initialize MediaRecorder settings
        if(mMediaRecorder == null) {
            mMediaRecorder = new MediaRecorder();
        }
        mMediaRecorder.reset();
        boolean microphoneOn = SettingsUtil.isMicrophoneOn(context);
        if (microphoneOn) {
            mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        } else {
            mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
        }
        mMediaRecorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        mMediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
        mMediaRecorder.setVideoFrameRate(30);
        int videoQuality = SettingsUtil.getVideoQuality(context);
        Log.i("Kaidi", "VideoQuality: " + videoQuality);
        if (videoQuality == 0)
            mMediaRecorder.setVideoEncodingBitRate(VQ_FINE);
        else
            mMediaRecorder.setVideoEncodingBitRate(VQ_NORMAL);

        res = getVideoSize(context);
        Log.e("Kaidi", res.width + " " + res.height);
        mMediaRecorder.setVideoSize(res.width, res.height);
        File file = new File(baseDir, getVideoName());
        mFilename = file.getAbsolutePath();
        mMediaRecorder.setOutputFile(mFilename);
        mContext = context;

        try {
            mMediaRecorder.prepare();
        } catch (IllegalStateException e) {
            Log.e(TAG, "Failed to prepare", e);
            return false;
        } catch (IOException e) {
            Log.e(TAG, "Failed to prepare", e);
            return false;
        }
        return true;
    }

    public Resolution getRes() {
        return res;
    }

    public Resolution getVideoSize(Context context) {
        // int videoSize = SettingsUtil.getVideoSize(context);
        int videoQuality = SettingsUtil.getVideoQuality(context);
        int width = 0;
        int height = 0;
        if (videoQuality == 0) {
            width = 1280;
            height = 720;
        } else if (videoQuality == 1) {
            width = 854;
            height = 480;
        }
        WindowManager windowManager = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        int rotation = display.getRotation();
        // Log.e("Kaidi", "rotation: " + rotation);
        if (rotation == 0 || rotation == 2) {
            int temp = width;
            width = height;
            height = temp;
        }
        return new Resolution(width, height);
    }

    public final static class Resolution {
        public int width;
        public int height;

        public Resolution() {
        }

        public Resolution(int width, int height) {
            this.width = width;
            this.height = height;
        }
    }

    /**
     * start record
     */
    public synchronized boolean start() {
        if (status != STATUS_IDLE)
            return true;
        status = STATUS_RECORDING;
        try {
            mMediaRecorder.start();
        } catch (RuntimeException e) {
            e.printStackTrace();
//            releaseMediaRecorder();
            mMediaRecorder.reset();
            status = STATUS_IDLE;
            return false;
        }
        return true;
    }

    /**
     * release mediaRecorder
     */
    private void releaseMediaRecorder() {
        if (mMediaRecorder != null) {
            mMediaRecorder.reset();
            mMediaRecorder.release();
            mMediaRecorder = null;
        }
    }

    /**
     * Stop record
     */
    public synchronized void stop(Context context) {
        if (status != STATUS_RECORDING)
            return;
        try {
            mMediaRecorder.setOnErrorListener(null);
            mMediaRecorder.stop();
            mMediaRecorder.reset();
            MediaScannerConnection.scanFile(mContext, new String[]{mFilename}, null,
                    new MediaScannerConnection.OnScanCompletedListener() {
                        public void onScanCompleted(String path, Uri uri) {
                            Log.d("Screen-corder", "Scan media database to update the gallery");
                            mFileMediaUri = uri;
                            Log.e("xuepeng", "uri = " + uri);
                        }
                    });

        } catch (Exception e) {
            Log.e(TAG, "Failed to stop", e);
        }
        // Toast.makeText(context, "Video save to " + mFilename,
        // Toast.LENGTH_SHORT).show();
        status = STATUS_IDLE;
    }

    public String getFilename() {
        return mFilename;
    }

    public static Uri getFileUri() {
        return mFileMediaUri;
    }

    /**
     * Get Surface object<br>
     * Should be called after initAndPrepare
     *
     * @return
     */
    public Surface getSurface() {
        return mMediaRecorder.getSurface();
    }

    /**
     * Generate video name by current date
     *
     * @return
     */
    private String getVideoName() {
        String format = "yyyy_MM_dd_hh_mm_ss";
        return DateFormat.format(format, new Date()) + ".mp4";
    }

    //add by yangyang2@tcl.com , fix bug 1250919 begin
    public void setErrorListener(MediaRecorder.OnErrorListener onErrorListener) {
        if(mMediaRecorder == null) {
            return;
        }
        mMediaRecorder.setOnErrorListener(onErrorListener);
    }
    //add by yangyang2@tcl.com , fix bug 1250919 begin
}
