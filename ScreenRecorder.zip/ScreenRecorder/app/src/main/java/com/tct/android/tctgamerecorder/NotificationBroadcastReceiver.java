
package com.tct.android.tctgamerecorder;

import java.io.File;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import com.tct.android.tctgamerecorder.editor.SettingsActivityGL;
import com.tct.android.tctgamerecorder.util.RecorderUtil;

public class NotificationBroadcastReceiver extends BroadcastReceiver {

    public final static String ACTION = "com.tct.android.tctgamerecorder.action";
    public final static String KEY_COMMAND = "command";
    public final static String KEY_FILENAME = "filename";
    public final static String COMMAND_CANCEL = "cancel";
    public final static String COMMAND_START = "start";
    public final static String COMMAND_STOP = "stop";
    public final static String COMMAND_VIEW = "view";
    public final static String COMMAND_SHARE = "share";
    public final static String COMMAND_TRIM = "trim";
    public final static String COMMAND_SETTINGS = "settings";
    private final static int NOTI_ID_FINISH = 1;
    private NotificationManager nm;

    @Override
    public void onReceive(Context context, Intent intent) {
        nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String command = intent
                .getStringExtra(KEY_COMMAND);
        String filename = intent.getStringExtra(KEY_FILENAME);
        if (COMMAND_VIEW.equals(command)) {
            // view a video file intent
            nm.cancel(NOTI_ID_FINISH);   
			Intent closeIntent = new Intent(RecordService.ACTION);
			closeIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_STOP);
			context.sendBroadcast(closeIntent);

			Intent viewIntent = new Intent("android.intent.action.VIEW");
            viewIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            viewIntent.putExtra("oneshot", 0);
            viewIntent.putExtra("configchange", 0);
            Log.i("Kaidi", "Filename : " + filename);
            Uri uri = Uri.fromFile(new File(filename));
            viewIntent.setDataAndType(uri, "video/*");
            context.startActivity(viewIntent);
        } else if (COMMAND_SHARE.equals(command)) {
            // share a video intent
            nm.cancel(NOTI_ID_FINISH);
			Intent closeIntent = new Intent(RecordService.ACTION);
			closeIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_STOP);
			context.sendBroadcast(closeIntent);

            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
            sharingIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            sharingIntent.setType("video/*");
            File newFile = new File(filename);
            sharingIntent.putExtra(android.content.Intent.EXTRA_STREAM, Uri.fromFile(newFile));
            context.startActivity(sharingIntent);
        } else if (COMMAND_TRIM.equals(command)) {
			Intent closeIntent = new Intent(RecordService.ACTION);
			closeIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_STOP);
			context.sendBroadcast(closeIntent);

			nm.cancel(NOTI_ID_FINISH);

            Uri uri = RecorderUtil.getFileUri();
            if (uri == null) {
                Log.e("Screen-corder", "Failed to get trim file's uri");
                return;
            }
            Log.e("Screen-corder", "Uri = " + uri.toString() + ", file = " + filename);
//            Intent trimIntent = new Intent("com.android.gallery.action.TRIM");
//            trimIntent.putExtra("media-item-path", filename);
            Intent trimIntent = new Intent(context, SettingsActivityGL.VideoTrimActivity.class);
            trimIntent.putExtra(SettingsActivityGL.VideoTrimActivity.KEY_FILEPATH, filename);
            trimIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            trimIntent.setData(uri);
    		context.startActivity(trimIntent);
        } else if (COMMAND_SETTINGS.equals(command)) {
            // Go to SettingsActivity intent
            Intent it = new Intent(context, SettingsActivityClean.class);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(it);
        }
    }
}
