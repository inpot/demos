package com.tct.android.tctgamerecorder.util;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;


/**
 * Created by yangyang on 11/20/15.
 */
public class ShowTouchesUtil {

    public static final String SETTINGS_SHOWTOUCHES = "show_touches";
    private static final String MIDDLE_MAN_URI = "content://com.tct.gapp.middleman/";

    public static void setShowTouches(Context context, boolean isShowing) {

        // todo, whether need to show touch, depend on the settings configuration

        // store current mode before begin record.
        int showTouchMode = 0;
        if(isShowing) {
            try {
                showTouchMode = Settings.System.getInt(context.getContentResolver(), SETTINGS_SHOWTOUCHES);
                Log.e("YY", "ShowTouch: " + showTouchMode);
            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
            }
        }
        // if show touches has already enabled before start, don't need to do any operations.
        if(showTouchMode == 1) {
            return;
        } else {
            int value = isShowing ? 1 : 0;
            int sdk_version = Build.VERSION.SDK_INT;
            try {
                if(sdk_version <= 22) {
                    Settings.System.putInt(context.getContentResolver(), SETTINGS_SHOWTOUCHES, value);
                } else {
                    boolean canWrite = Settings.System.canWrite(context);
                    if(canWrite) {
                        Settings.System.putInt(context.getContentResolver(), SETTINGS_SHOWTOUCHES, value);
                    } else {
                        Log.e("YY", "Middle man result :" + tryUseMiddleManSetShowTouch(context, isShowing));
                    }
                }
            } catch (Exception e){
                e.printStackTrace();
                Log.e("YY", "Set show touches failed.");
                Log.e("YY", "Middle man result :" + tryUseMiddleManSetShowTouch(context, isShowing));
            }
        }
    }

    public static boolean getShowTouches(Context context){
        int value = Settings.System.getInt(context.getContentResolver(), "show_touches", 0);
        if(value == 0) {
            return false;
        }
        return true;
    }

    /**
     * This method will try to using 3rd apk 'middleman' to open showtouhs, More information please
     * check 'Middleman Document'
     * @return 1 success <br>
     *        2 middleman not have request method or you provide parameters is wrong <br>
     *        3 not have request method <br>
     *        4 package name is null <br>
     *        5 this apk not register to middleman <br>
     *        -1 happen error or not have 'middleman' apk in system
     * */
    private static int tryUseMiddleManSetShowTouch(Context context, boolean isShowing) {
        try {
            String package_name = context.getPackageName();
            String parameter = isShowing == true ? "1" : "0";
            Uri uri = Uri.parse(MIDDLE_MAN_URI + package_name);
            Cursor cursor = context.getContentResolver().query(uri, null, "setShowTouchs",
                    new String[]{parameter}, null);
            if(cursor == null) {
                Log.e("YY", "This phone not have  MiddleMan application.");
                return -1;
            }
            Bundle bundle = cursor.getExtras();
            if(bundle == null) {
                return -1;
            }
            return bundle.getInt("result_code");
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("YY", "Use middle man set showtouces happen error!");
            return -1;
        }
    }
}
