
package com.tct.android.tctgamerecorder.util;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicReference;

import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.util.Log;
import android.view.Surface;

public class MediaCodecUtil {

    private final static String TAG = "MediaCodecUtil";
    private static final String OUTPUT_VIDEO_MIME_TYPE = "video/avc";
    private static final int OUTPUT_VIDEO_FRAME_RATE = 30; // 30fps
    private static final int OUTPUT_VIDEO_IFRAME_INTERVAL = 10;
    private static final int OUTPUT_VIDEO_COLOR_FORMAT =
            MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface;
    // private static final String KEY_ROTATION_DEGREE = "rotation-degrees";
    /** How long to wait for the next buffer to become available. */
    private static final int TIMEOUT_USEC = 10000;

    private String mOutputFilePath;
    private String mVideoFilePath;
    private long mStartTimestampUs;
    private long mEndTimestampUs;
    private boolean outputAvailable = false;

    public synchronized boolean trim(String videoPath, long mStartTimestampUs,
            long mEndTimestampUs, String outputPath) throws Exception {
        mOutputFilePath = outputPath;
        mVideoFilePath = videoPath;
        this.mStartTimestampUs = mStartTimestampUs;
        this.mEndTimestampUs = mEndTimestampUs;

        MediaCodecInfo videoCodecInfo = selectCodec(OUTPUT_VIDEO_MIME_TYPE);
        if (videoCodecInfo == null) {
            // Don't fail if they don't have an AVC codec (not here, anyway).
            Log.e(TAG, "Unable to find an appropriate codec for " + OUTPUT_VIDEO_MIME_TYPE);
            return false;
        }

        MediaExtractor videoExtractor = null;
        OutputSurface outputSurface = null;
        MediaCodec videoDecoder = null;
        MediaCodec videoEncoder = null;
        MediaMuxer muxer = null;

        InputSurface inputSurface = null;

        try {
            videoExtractor = createVideoExtractor();
            int videoInputTrack = getAndSelectVideoTrackIndex(videoExtractor);
            if (videoInputTrack == -1) {
                Log.e(TAG, "missing video track in source video");
                return false;
            }
            MediaFormat inputFormat = videoExtractor.getTrackFormat(videoInputTrack);

            int width = inputFormat.getInteger(MediaFormat.KEY_WIDTH);
            int height = inputFormat.getInteger(MediaFormat.KEY_HEIGHT);
            Log.i(TAG, "input video width=" + width + ", height=" + height);

            // We avoid the device-specific limitations on width and height by
            // using values
            // that are multiples of 16, which all tested devices seem to be
            // able to handle.
            MediaFormat outputVideoFormat =
                    MediaFormat.createVideoFormat(OUTPUT_VIDEO_MIME_TYPE, width, height);
            int bitRate = width * height * OUTPUT_VIDEO_FRAME_RATE;
            // Set some properties. Failing to specify some of these can cause
            // the MediaCodec
            // configure() call to throw an unhelpful exception.
            outputVideoFormat.setInteger(
                    MediaFormat.KEY_COLOR_FORMAT, OUTPUT_VIDEO_COLOR_FORMAT);
            outputVideoFormat.setInteger(MediaFormat.KEY_BIT_RATE, bitRate);
            outputVideoFormat.setInteger(MediaFormat.KEY_FRAME_RATE, OUTPUT_VIDEO_FRAME_RATE);
            outputVideoFormat.setInteger(
                    MediaFormat.KEY_I_FRAME_INTERVAL, OUTPUT_VIDEO_IFRAME_INTERVAL);
            // Integer orientation =
            // inputFormat.getInteger(KEY_ROTATION_DEGREE);
            // int rotation = orientation == null ? 0 : orientation;
            int rotation = 0;

            // Create a MediaCodec for the desired codec, then configure it as
            // an encoder with
            // our desired properties. Request a Surface to use for input.
            AtomicReference<Surface> inputSurfaceReference = new AtomicReference<Surface>();
            videoEncoder = createVideoEncoder(
                    videoCodecInfo, outputVideoFormat, inputSurfaceReference);
            inputSurface = new InputSurface(inputSurfaceReference.get());
            inputSurface.makeCurrent();
            // Create a MediaCodec for the decoder, based on the extractor's
            // format.
            outputSurface = new OutputSurface();
            videoDecoder = createVideoDecoder(inputFormat, outputSurface.getSurface());

            // Creates a muxer but do not start or add tracks just yet.
            muxer = createMuxer();

            if (rotation != 0) {
                muxer.setOrientationHint(rotation);
                outputSurface.setRotation((360 - rotation) % 360);
            }

            doExtractDecodeEditEncodeMux(
                    videoExtractor,
                    videoDecoder,
                    videoEncoder,
                    muxer,
                    inputSurface,
                    outputSurface);

            outputAvailable = true;
        } catch (Exception e) {
            throw e;
        } finally {

            // Try to release everything we acquired, even if one of the
            // releases fails, in which
            // case we save the first exception we got and re-throw at the end
            // (unless something
            // other exception has already been thrown). This guarantees the
            // first exception thrown
            // is reported as the cause of the error, everything is (attempted)
            // to be released, and
            // all other exceptions appear in the logs.
            try {
                if (videoExtractor != null) {
                    videoExtractor.release();
                }
            } catch (Exception e) {
                Log.e(TAG, "error while releasing videoExtractor", e);

            }
            try {
                if (videoDecoder != null) {
                    videoDecoder.stop();
                    videoDecoder.release();
                }
            } catch (Exception e) {
                Log.e(TAG, "error while releasing videoDecoder", e);

            }
            try {
                if (outputSurface != null) {
                    outputSurface.release();
                }
            } catch (Exception e) {
                Log.e(TAG, "error while releasing outputSurface", e);

            }
            try {
                if (videoEncoder != null) {
                    videoEncoder.stop();
                    videoEncoder.release();
                }
            } catch (Exception e) {
                Log.e(TAG, "error while releasing videoEncoder", e);

            }
            try {
                if (muxer != null) {
                    muxer.stop();
                    muxer.release();
                }
            } catch (Exception e) {
                Log.e(TAG, "error while releasing muxer", e);

                outputAvailable = false;
            }
            try {
                if (inputSurface != null) {
                    inputSurface.release();
                }
            } catch (Exception e) {
                Log.e(TAG, "error while releasing inputSurface", e);

            }
        }
        return outputAvailable;
    }

    private void doExtractDecodeEditEncodeMux(
            MediaExtractor videoExtractor,
            MediaCodec videoDecoder,
            MediaCodec videoEncoder,
            MediaMuxer muxer,
            InputSurface inputSurface,
            OutputSurface outputSurface) {
        MediaCodec.BufferInfo videoDecoderOutputBufferInfo = new MediaCodec.BufferInfo();
        MediaCodec.BufferInfo videoEncoderOutputBufferInfo = new MediaCodec.BufferInfo();
        // We will get these from the decoders when notified of a format change.
        MediaFormat decoderOutputVideoFormat = null;
        // We will get these from the encoders when notified of a format change.
        MediaFormat encoderOutputVideoFormat = null;
        // We will determine these once we have the output format.
        int outputVideoTrack = -1;
        // Whether things are done on the video side.
        boolean videoExtractorDone = false;
        boolean videoDecoderDone = false;
        boolean videoEncoderDone = false;

        boolean muxing = false;

        int videoExtractedFrameCount = 0;
        int videoDecodedFrameCount = 0;
        int videoEncodedFrameCount = 0;
        // We should recalculate start and end timestamp between I-frames.
        final long videoStartTimestamp = mStartTimestampUs;
        if (mEndTimestampUs != Long.MAX_VALUE) {
            videoExtractor.seekTo(mEndTimestampUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC);
            mEndTimestampUs = videoExtractor.getSampleTime();
        }
        final long videoStopTimestamp = mEndTimestampUs;
        videoExtractor.seekTo(videoStartTimestamp, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

        while (!videoEncoderDone) {
            // Extract video from file and feed to decoder.
            // Do not extract video if we have determined the output format but
            // we are not yet
            // ready to mux the frames.
            while (!videoExtractorDone && (encoderOutputVideoFormat == null || muxing)) {
                long presentationTime = videoExtractor.getSampleTime();

                if (presentationTime >= videoStopTimestamp) {
                    Log.d(TAG, "video extractor reach end timestamp");
                    videoExtractorDone = true;
                }
                int decoderInputBufferIndex = videoDecoder.dequeueInputBuffer(TIMEOUT_USEC);
                if (decoderInputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {

                    break;
                }

                ByteBuffer decoderInputBuffer = videoDecoder
                        .getInputBuffer(decoderInputBufferIndex);
                if (!videoExtractorDone) {
                    int size = videoExtractor.readSampleData(decoderInputBuffer, 0);

                    presentationTime -= videoStartTimestamp;
                    if (size >= 0) {
                        videoDecoder.queueInputBuffer(
                                decoderInputBufferIndex,
                                0,
                                size,
                                presentationTime,
                                videoExtractor.getSampleFlags());
                    }
                    videoExtractedFrameCount++;
                    videoExtractorDone = !videoExtractor.advance();
                }
                if (videoExtractorDone) {

                    videoDecoder.queueInputBuffer(
                            decoderInputBufferIndex,
                            0,
                            0,
                            0,
                            MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                }

                // We extracted a frame, let's try something else next.
                break;
            }

            // Poll output frames from the video decoder and feed the encoder.
            while (!videoDecoderDone && (encoderOutputVideoFormat == null || muxing)) {
                int decoderOutputBufferIndex =
                        videoDecoder.dequeueOutputBuffer(
                                videoDecoderOutputBufferInfo, TIMEOUT_USEC);
                if (decoderOutputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {

                    break;
                }
                if (decoderOutputBufferIndex == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {

                    break;
                }
                if (decoderOutputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    decoderOutputVideoFormat = videoDecoder.getOutputFormat();

                    break;
                }

                ByteBuffer videoDecoderOutputBuffers = videoDecoder
                        .getOutputBuffer(decoderOutputBufferIndex);
                if ((videoDecoderOutputBufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)
                != 0) {

                    videoDecoder.releaseOutputBuffer(decoderOutputBufferIndex, false);
                    break;
                }

                boolean render = videoDecoderOutputBufferInfo.size != 0;
                videoDecoder.releaseOutputBuffer(decoderOutputBufferIndex, render);
                if (render) {

                    outputSurface.awaitNewImage();
                    // Edit the frame and send it to the encoder.

                    outputSurface.drawImage();
                    inputSurface.setPresentationTime(
                            videoDecoderOutputBufferInfo.presentationTimeUs * 1000);

                    inputSurface.swapBuffers();

                }
                if ((videoDecoderOutputBufferInfo.flags
                & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {

                    videoDecoderDone = true;
                    videoEncoder.signalEndOfInputStream();
                }
                videoDecodedFrameCount++;
                // We extracted a pending frame, let's try something else next.
                break;
            }

            // Poll frames from the video encoder and send them to the muxer.
            while (!videoEncoderDone && (encoderOutputVideoFormat == null || muxing)) {
                int encoderOutputBufferIndex = videoEncoder.dequeueOutputBuffer(
                        videoEncoderOutputBufferInfo, TIMEOUT_USEC);
                if (encoderOutputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {

                    break;
                }
                if (encoderOutputBufferIndex == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {

                    break;
                }
                if (encoderOutputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {

                    if (outputVideoTrack >= 0) {
                        Log.e(TAG, "video encoder changed its output format again?");
                        break;
                    }
                    encoderOutputVideoFormat = videoEncoder.getOutputFormat();
                    break;
                }
                if (!muxing) {
                    Log.e(TAG, "should have added track before processing output");
                    break;
                }

                ByteBuffer encoderOutputBuffer = videoEncoder.getOutputBuffer(
                        encoderOutputBufferIndex);
                if ((videoEncoderOutputBufferInfo.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG)
                != 0) {
                    // Simply ignore codec config buffers.
                    videoEncoder.releaseOutputBuffer(encoderOutputBufferIndex, false);
                    break;
                }

                if (videoEncoderOutputBufferInfo.size != 0) {
                    muxer.writeSampleData(
                            outputVideoTrack, encoderOutputBuffer, videoEncoderOutputBufferInfo);
                }
                if ((videoEncoderOutputBufferInfo.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                != 0) {
                    videoEncoderDone = true;
                }
                videoEncoder.releaseOutputBuffer(encoderOutputBufferIndex, false);
                videoEncodedFrameCount++;
                // We enqueued an encoded frame, let's try something else next.
                break;
            }

            if (!muxing && encoderOutputVideoFormat != null) {
                Log.d(TAG, "muxer: adding video track.");
                outputVideoTrack = muxer.addTrack(encoderOutputVideoFormat);
                Log.d(TAG, "muxer: starting");
                muxer.start();
                muxing = true;
            }
        }
    }

    /**
     * Returns the first codec capable of encoding the specified MIME type, or
     * null if no match was found.
     */
    @SuppressWarnings("deprecation")
    private static MediaCodecInfo selectCodec(String mimeType) {
        int numCodecs = MediaCodecList.getCodecCount();
        for (int i = 0; i < numCodecs; i++) {
            MediaCodecInfo codecInfo = MediaCodecList.getCodecInfoAt(i);

            if (!codecInfo.isEncoder()) {
                continue;
            }

            String[] types = codecInfo.getSupportedTypes();
            for (int j = 0; j < types.length; j++) {
                if (types[j].equalsIgnoreCase(mimeType)) {
                    return codecInfo;
                }
            }
        }
        return null;
    }

    /**
     * Creates an extractor that reads its frames from {@link #mSourceResId}.
     */
    private MediaExtractor createVideoExtractor() throws IOException {
        MediaExtractor extractor;
        extractor = new MediaExtractor();
        extractor.setDataSource(mVideoFilePath);
        return extractor;
    }

    /**
     * Creates a decoder for the given format, which outputs to the given
     * surface.
     *
     * @param inputFormat the format of the stream to decode
     * @param surface into which to decode the frames
     */
    private MediaCodec createVideoDecoder(MediaFormat inputFormat, Surface surface)
            throws IOException {
        MediaCodec decoder = MediaCodec.createDecoderByType(getMimeTypeFor(inputFormat));
        decoder.configure(inputFormat, surface, null, 0);
        decoder.start();
        return decoder;
    }

    /**
     * Creates an encoder for the given format using the specified codec, taking
     * input from a surface.
     * <p>
     * The surface to use as input is stored in the given reference.
     *
     * @param codecInfo of the codec to use
     * @param format of the stream to be produced
     * @param surfaceReference to store the surface to use as input
     */
    private MediaCodec createVideoEncoder(
            MediaCodecInfo codecInfo,
            MediaFormat format,
            AtomicReference<Surface> surfaceReference)
            throws IOException {
        MediaCodec encoder = MediaCodec.createByCodecName(codecInfo.getName());
        encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        // Must be called before start() is.
        surfaceReference.set(encoder.createInputSurface());
        encoder.start();
        return encoder;
    }

    /**
     * Creates a muxer to write the encoded frames.
     * <p>
     * The muxer is not started as it needs to be started only after all streams
     * have been added.
     */
    private MediaMuxer createMuxer() throws IOException {
        return new MediaMuxer(mOutputFilePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
    }

    private int getAndSelectVideoTrackIndex(MediaExtractor extractor) {
        for (int index = 0; index < extractor.getTrackCount(); ++index) {
            if (isVideoFormat(extractor.getTrackFormat(index))) {
                extractor.selectTrack(index);
                return index;
            }
        }
        return -1;
    }

    private static boolean isVideoFormat(MediaFormat format) {
        return getMimeTypeFor(format).startsWith("video/");
    }

    private static String getMimeTypeFor(MediaFormat format) {
        return format.getString(MediaFormat.KEY_MIME);
    }
}
