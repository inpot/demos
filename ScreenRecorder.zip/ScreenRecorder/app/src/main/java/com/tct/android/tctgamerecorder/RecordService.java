
package com.tct.android.tctgamerecorder;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.Parameters;
import android.hardware.Camera.PreviewCallback;
import android.hardware.Camera.Size;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.provider.Settings;
import android.service.notification.StatusBarNotification;
import android.support.v4.app.NotificationCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.TextureView;
import android.view.TextureView.SurfaceTextureListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.tct.android.tctgamerecorder.layout.MyRelativeLayout;
import com.tct.android.tctgamerecorder.util.CameraHelper;
import com.tct.android.tctgamerecorder.util.ImageUtil;
import com.tct.android.tctgamerecorder.util.PermissionUtil;
import com.tct.android.tctgamerecorder.util.RecorderUtil;
import com.tct.android.tctgamerecorder.util.RecorderUtil.Resolution;
import com.tct.android.tctgamerecorder.util.ReflectionMethod;
import com.tct.android.tctgamerecorder.util.SettingsUtil;
import com.tct.android.tctgamerecorder.util.ShowTouchesUtil;

import java.io.File;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

@SuppressWarnings("deprecation")
public class RecordService extends Service {

    // Commands
    public final static String ACTION = "com.tct.android.tctgamerecorder.action";
    public final static String KEY_COMMAND = "command";
    public final static String KEY_FILENAME = "filename";
    public final static String COMMAND_CANCEL = "cancel";
    public final static String COMMAND_START = "start";
    public final static String COMMAND_STOP = "stop";
    public final static String COMMAND_VIEW = "view";
    public final static String COMMAND_SHARE = "share";
    public final static String COMMAND_TRIM = "trim";
    public final static String COMMAND_CAMERA = "camera";
    public final static String COMMAND_CAMERA_NOTIFICATION = "camera_notification";
    public final static String COMMAND_PREVIEW_SIZE = "preview_size";
    public final static String COMMAND_PREVIEW_SIZE_NOTIFICATION = "preview_size_notification";
    public final static String COMMAND_UPDATE_SETTINGS_STATUS_CAMERA = "update_settings_activity_status_camera";
    public final static String COMMAND_UPDATE_SETTINGS_STATUS_PREVIEWSIZE = "update_settings_activity_status_preview_size";
    public final static String COMMMAN_FINISH_PROJECTION_ACTIVITY = "finish_projection_activity";
    public final static String COMMAND_PERMISSION_ACTIVITY_STOP = "permission_activity_stopped";
    public final static String COMMAND_CAMERA_TRY_RUN = "camera_try_to_open";
    public final static String COMMAND_SHOWTOUCHES_STATE_CHANGE = "showtouches_state_changed";
    public final static String COMMAND_RECORDING_ERROR = "recording_happen_error";
    //error type
    public final static String EXTRA_ERROR_TYPE = "error_type";
    public final static int INIT_RECORDER_ERROR = 0x10;
    public final static int START_RECORDER_ERROR = 0x11;
    public final static int INIT_CAMERA_ERROR = 0x12;
    public final static int USING_CAMERA_ERROR = 0x13;
    public final static int USING_MEDIARECORDER_ERROR = 0x014;
    //service name
    public final static String WIFI_DISPLAY_SERVICE_NAME = "com.qualcomm.wfd.service.WfdService";
    public final static String CAMERA_DISPLAY_SERVICE_NAME = "com.android.camera.MediaSaveService";
    //start service action
    private  String quickStartRecordServiceAction = "com.tct.screenrecorder.recordservice.LAUNCH";

    public static MediaProjection mMediaProjection;

    // Floating UI
    private final static int STATE_IDLE = 0;
    private final static int STATE_PENDING_RECORD = 1;
    private final static int STATE_RECORDING = 2;
    private final static int STATE_SAVING = 3;
    private Context appContext;
    private LayoutInflater mLayoutInflater;
    private WindowManager windowManager;
    private WindowManager.LayoutParams wmParams;
    private Display display;
    private MyRelativeLayout mContainer;
    private TextView mRecordView;
    private RelativeLayout mHintView;
    private TextView mHintText;
    private TextureView mTextureView;
    private Camera mCamera;
    private CameraInfo mCameraInfo = new CameraInfo();
    private int previewWidth;
    private int previewHeight;
    private int state = STATE_IDLE;
    private long animStartTime = 0;
    private long recordStartTime = 0;
    private boolean isBoostAnimating = false;
    private boolean onDestorying = false;

    // For screen record
    private final static int NOTI_ID_FINISH = 1;
    private final static int NOTI_ID_SERVICE = 2;
    public final static int REQUEST_CODE_VIEW = 100;
    public final static int REQUEST_CODE_SHARE = 101;
    public final static int REQUEST_CODE_TRIM = 102;
    public final static int REQUEST_CODE_SETTINGS = 103;
    public final static int REQUEST_CODE_CLOSE = 104;
    public final static int REQUEST_CODE_CAMERA = 105;
    public final static int REQUEST_CODE_PREVIEW_SIZE = 106;

    private static int DEFAULT_FLOAT_VIEW_WIDTH = 130;
    private static int DEFAULT_FLOAT_VIEW_HEIGHT = 130;
    private final static int FLOAT_VIEW_PADDING_TO_BOTTOM_FULLSCREEEN = 100;
    private final static int GAP_BETWEEN_HINT_TEXT_WITH_FLOAT_VIEW = 20;

    private NotificationManager nm;
    private RecorderUtil mRecorderUtil;
    private int mScreenDensity;
    private int mStatusBarHeight;
    private int mScreenHeight;
    private int mScreenWidth;
    private Bitmap mFrameBmp;

    private VirtualDisplay mVirtualDisplay;

    //default system showtouches state
    private boolean systemEnabledTouchesState;

    //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
    private RecordHandler mHandler;
    private Timer mCallTimer = null;
    private TimerTask mTask = null;
    //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String command = intent.getStringExtra(KEY_COMMAND);
            String actionStr = intent.getAction();

            if (Intent.ACTION_SCREEN_OFF.equals(actionStr)) {
                if (state == STATE_PENDING_RECORD || state == STATE_RECORDING) {
                    Log.e("Screen-corder", "lock screen when recording");
                    Intent it = new Intent(RecordService.ACTION);
                    it.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_STOP);
                    sendBroadcast(it);
                    return;
                }
            } else if (ACTION.equals(actionStr)){
                if (COMMAND_CANCEL.equals(command)) {
                    if (mCamera != null)
                        mCamera.setPreviewCallback(null);
                    if (mTextureView != null)
                        mTextureView.setVisibility(View.GONE);
                    mContainer.removeView(mTextureView);
                    mContainer.setBackgroundColor(Color.TRANSPARENT);
                    mRecordView.setText("");
                    //mRecordView.setBackgroundResource(R.drawable.gc_icon_rec);
                    state = STATE_IDLE;
                } else if (COMMAND_CAMERA_NOTIFICATION.equals(command)) {
                    //modfied by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
                    boolean cameraOnOff = SettingsUtil.usingFrontCamera(RecordService.this);
                    if(state == STATE_RECORDING) {
                        if(cameraOnOff) {
                            closeCameraWhenRecording();
                        } else {
                            //try to start camera preview. First ,Init textureView ,
                            // when it done ,it's callback method will init camera
                            initTextureView();
                            SettingsUtil.setFrontCamera(RecordService.this, true);
                            updateFloatViewSize();
                            showForegroundNotification();
                            Intent updateSettingsCameraStatusIntent = new Intent(RecordService.ACTION);
                            updateSettingsCameraStatusIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_UPDATE_SETTINGS_STATUS_CAMERA);
                            RecordService.this.sendBroadcast(updateSettingsCameraStatusIntent);
                        }
                    } else {
                        SettingsUtil.setFrontCamera(RecordService.this, !cameraOnOff);
                        updateFloatViewSize();
                        showForegroundNotification();
                        Intent updateSettingsCameraStatusIntent = new Intent(RecordService.ACTION);
                        updateSettingsCameraStatusIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_UPDATE_SETTINGS_STATUS_CAMERA);
                        RecordService.this.sendBroadcast(updateSettingsCameraStatusIntent);
                    }
                } else if (COMMAND_CAMERA.equals(command)) {
                    if(state == STATE_RECORDING) {
                        boolean cameraOnOff = SettingsUtil.usingFrontCamera(RecordService.this);
                        if(!cameraOnOff) {
                            closeCameraWhenRecording();
                        } else {
                            //try to start camera preview. First ,Init textureView ,
                            // when it done ,it's callback method will init camera
                            initTextureView();
                            updateFloatViewSize();
                            showForegroundNotification();
                        }
                    } else {
                        updateFloatViewSize();
                        showForegroundNotification();
                    }
                    //modfied by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end
                } else if (COMMAND_PREVIEW_SIZE_NOTIFICATION.equals(command)) {
                    int prefrenceVal = SettingsUtil.getFrontCameraPreviewPreferenceValue(RecordService.this);
                    prefrenceVal = (++prefrenceVal)%3;
                    SettingsUtil.setFrontCameraPreviewPreferenceValue(RecordService.this, prefrenceVal);
                    updateFloatViewSize();
                    showForegroundNotification();

                    Intent updateSettingsSizeStatusIntent = new Intent(RecordService.ACTION);
                    updateSettingsSizeStatusIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_UPDATE_SETTINGS_STATUS_PREVIEWSIZE);
                    RecordService.this.sendBroadcast(updateSettingsSizeStatusIntent);
                } else if (COMMAND_PREVIEW_SIZE.equals(command)) {
                    updateFloatViewSize();
                    showForegroundNotification();
                } else if (COMMAND_START.equals(command)) {
                    prepareForRecording();
                } else if (COMMAND_STOP.equals(command)) {
                    if (mHintView != null) {
                        windowManager.removeView(mHintView);
                        mHintView = null;
                    }
                    RecordService.this.stopSelf();
                } else if (COMMAND_CAMERA_TRY_RUN.equals(command)) {
                    Toast.makeText(RecordService.this, R.string.msg_screencorder_running_close_to_continue_camera, Toast.LENGTH_SHORT).show();
                } else if (COMMAND_SHOWTOUCHES_STATE_CHANGE.equals(command)) {
                    if(state == STATE_RECORDING){
                        boolean isShowTouches = SettingsUtil.getShowTouchesStatus(RecordService.this);
                        Log.i("showtouches","At settings have changed showtouches to->" + isShowTouches);
//                        showTouches(isShowTouches);
                        ShowTouchesUtil.setShowTouches(appContext, isShowTouches);
                    }
                    //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
                } else if(COMMAND_RECORDING_ERROR.equals(command)) {
                    //when happen some error , handle it
                    int errorType = intent.getIntExtra(EXTRA_ERROR_TYPE, -1);
                    handleRecordingError(errorType);
                }
                //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end
            } else if(Intent.ACTION_SHUTDOWN.equals(actionStr)) {
                if(state == STATE_RECORDING) {
                    Log.i("RecordService", "Phone power down! Trying to stop record.");
                    stopRecord();
                }
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("Kaidi", "RecordService Create");
        appContext = getApplicationContext();
        boolean isDone = PermissionUtil.checkPermissionIsAllGranted(this, PermissionUtil.IntegrantPermissions);
        if(!isDone) {
            Toast.makeText(this, appContext.getString(R.string.permission_notify_requirement_deny),
                    Toast.LENGTH_LONG).show();
            RecordService.this.stopSelf();
        }
        //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
        mHandler = new RecordHandler(this);
        //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end
        SettingsUtil.setScreenRecordOn(this, true);
        initFrontCameraPreviewSize();
        mLayoutInflater = LayoutInflater.from(appContext);
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_SHUTDOWN);
        this.registerReceiver(mReceiver, filter);

        // Initialize media projection
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mRecorderUtil = new RecorderUtil();
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager = (WindowManager) getApplicationContext().getSystemService(
                Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(metrics);
        display = windowManager.getDefaultDisplay();
        mScreenDensity = metrics.densityDpi;
        mStatusBarHeight = getStatusBarHeight();
        mScreenHeight = display.getHeight();
        mScreenWidth = display.getWidth();
        //modified by yangyang2@tcl.com, fix bug 788448 begin
        setDefaultFloatViewSize();
        //modified by yangyang2@tcl.com, fix bug 788448 end
        showFloatingView();
        if (SettingsUtil.checkScreenRecorderFirstTimeRun(this) == true ) {
            showHintView();
        }

        showForegroundNotification();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        // intent is null when restart by system
        if(intent == null) {
            return super.onStartCommand(intent, flags, startId);
        }

        boolean autoRecorde = false;
        if(quickStartRecordServiceAction.equals(intent.getAction())){
            autoRecorde = true;
        }
        Log.i("RecirdService", "record service-> onStartCommand: startrecord:" + autoRecorde);
        if(autoRecorde){
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mHintView != null) {
                        mHintView.callOnClick();
                    }
                    if (mRecordView != null && state == STATE_IDLE) {
                        Log.i("RecirdService", "call record!");
                        mRecordView.callOnClick();
                    }
                }
            }, 1500);
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if(windowManager == null){
            windowManager = (WindowManager) getApplicationContext().getSystemService(
                    Context.WINDOW_SERVICE);
        }
        display = windowManager.getDefaultDisplay();
        mStatusBarHeight = getStatusBarHeight();
        mScreenHeight = display.getHeight();
        mScreenWidth = display.getWidth();
        Log.i("RecorderService", "System orientation have changed :" + newConfig.orientation +
                "New height:" + mScreenHeight + " New width: " + mScreenWidth);
        updateFloatViewSize();
    }

    private void setDefaultFloatViewSize(){
        if(mScreenHeight > mScreenWidth){
            DEFAULT_FLOAT_VIEW_WIDTH = mScreenWidth / 5;
        }else {
            DEFAULT_FLOAT_VIEW_WIDTH = mScreenHeight / 5;
        }
        DEFAULT_FLOAT_VIEW_HEIGHT = DEFAULT_FLOAT_VIEW_WIDTH;
    }

    /**
     * Get StatusBar height, used in Floating UI
     *
     * @return
     */
    public int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
    private void handleRecordingError(int errorType) {
        switch (errorType) {
            case INIT_RECORDER_ERROR:
                Toast.makeText(RecordService.this, R.string.error_init_recorder, Toast.LENGTH_LONG).show();
                RecordService.this.stopSelf();
                break;
            case START_RECORDER_ERROR:
                Toast.makeText(RecordService.this, R.string.error_start_recorder, Toast.LENGTH_SHORT).show();
                //modified by yangyang2@tcl.com , fix bug 1250919 begin
//                RecordService.this.stopSelf();
                resetToInitialStatue();
                //modified by yangyang2@tcl.com , fix bug 1250919 end
                break;
            case INIT_CAMERA_ERROR:
                closeCameraWhenRecording();
                break;
            case USING_CAMERA_ERROR:
                Toast.makeText(RecordService.this, R.string.error_using_camera , Toast.LENGTH_LONG).show();
                closeCameraWhenRecording();
                break;
            //add by yangyang2@tcl.com , fix bug 1250919 begin
            case USING_MEDIARECORDER_ERROR:
                Toast.makeText(RecordService.this, R.string.error_using_mediarecorder , Toast.LENGTH_LONG).show();
                resetToInitialStatue();
                break;
            //add by yangyang2@tcl.com , fix bug 1250919 end
            default:
                break;
        }
    }
    //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end

    // Show foreground notification with this service
    private void showForegroundNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                appContext);
        builder.setSmallIcon(R.drawable.ic_recorder);
        builder.setTicker(getString(R.string.app_name));
        builder.setWhen(System.currentTimeMillis());
        builder.setAutoCancel(false);
        CharSequence contentTitle = getString(R.string.app_name);
        CharSequence contentText = getString(R.string.msg_app_running);
        builder.setContentTitle(contentTitle);
        builder.setContentText(contentText);
        Intent settingsIntent = new Intent(appContext, SettingsActivityClean.class);
        settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent settingsPendingIntent = PendingIntent
                .getActivity(appContext, REQUEST_CODE_SETTINGS, settingsIntent, 0);
        builder.setContentIntent(settingsPendingIntent);

        Intent cameraOnOffIntent = new Intent(ACTION);
        cameraOnOffIntent.putExtra(KEY_COMMAND, COMMAND_CAMERA_NOTIFICATION);
        PendingIntent cameraOnOffPendingIntent = PendingIntent.getBroadcast(appContext,
                REQUEST_CODE_CAMERA, cameraOnOffIntent, 0);

        Intent cameraPreviewSizeIntent = new Intent(ACTION);
        cameraPreviewSizeIntent.putExtra(KEY_COMMAND, COMMAND_PREVIEW_SIZE_NOTIFICATION);
        PendingIntent cameraPreviewSizePendingIntent = PendingIntent.getBroadcast(appContext,
                REQUEST_CODE_PREVIEW_SIZE, cameraPreviewSizeIntent, 0);

        Intent stopIntent = new Intent(ACTION);
        stopIntent.putExtra(KEY_COMMAND, COMMAND_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getBroadcast(appContext,
                REQUEST_CODE_CLOSE, stopIntent, 0);

        int frontCameraIconId = R.drawable.ic_front_camera_on;
        if (SettingsUtil.usingFrontCamera(RecordService.this) == false) {
            frontCameraIconId = R.drawable.ic_front_camera_off;
        }

        int screenSizeIconId = R.drawable.ic_small;
        if (SettingsUtil.getFrontCameraPreviewPreferenceValue(RecordService.this) == SettingsUtil.SCREEN_SIZE_LARGE) {
            screenSizeIconId = R.drawable.ic_large;
        } else if (SettingsUtil.getFrontCameraPreviewPreferenceValue(RecordService.this) == SettingsUtil.SCREEN_SIZE_FULL_SCREEN) {
            screenSizeIconId = R.drawable.ic_fullscreen;
        }

        int stopIconId = R.drawable.ic_notification_close;
        if (state == STATE_RECORDING) {
            stopIconId = R.drawable.ic_notification_stop;
        }

        builder.addAction(frontCameraIconId, null, cameraOnOffPendingIntent);
        builder.addAction(screenSizeIconId, null, cameraPreviewSizePendingIntent);
        builder.addAction(stopIconId, null, stopPendingIntent);
        this.startForeground(NOTI_ID_SERVICE, builder.build());
    }

    /**
     * show floating view
     */
    private void showFloatingView() {
        wmParams = new WindowManager.LayoutParams();
        wmParams.type = LayoutParams.TYPE_TOAST;
        wmParams.format = PixelFormat.RGBA_8888;
        //modified by yangyang2@tcl.com ,for bug 811861 begin
        wmParams.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
                | LayoutParams.FLAG_NOT_FOCUSABLE;
//                | LayoutParams.FLAG_KEEP_SCREEN_ON;
        //modified by yangyang2@tcl.com ,for bug 811861 end

        wmParams.gravity = Gravity.START | Gravity.TOP;
        int rightMargin = 30;
        wmParams.x = mScreenWidth - DEFAULT_FLOAT_VIEW_WIDTH - rightMargin;
        wmParams.y = mScreenHeight/2  ;
        wmParams.width = DEFAULT_FLOAT_VIEW_WIDTH;
        wmParams.height = DEFAULT_FLOAT_VIEW_HEIGHT;

        mContainer = (MyRelativeLayout) mLayoutInflater
                .inflate(R.layout.comp_floating_texture_new,
                        null);
        mRecordView = (TextView) mContainer
                .findViewById(R.id.RecordView);
        mContainer.set(this, windowManager, wmParams, mStatusBarHeight);

        mRecordView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                if (state == STATE_IDLE) {
                    if (getExclusionService() == true) {
                        return;
                    }

                    if (getWifiDisplayRunningState() == true) {
                        return;
                    }
                    state = STATE_PENDING_RECORD;
                    tryShareScreen();
                } else if (state == STATE_RECORDING) {
                    stopAndNotify();
                    //add by yangyang2@tcl.com, fix bug 1305216 begin
                } else if (state == STATE_PENDING_RECORD) {
                    tryShareScreen();
                    Toast.makeText(RecordService.this, R.string.pending_permission_no_response,
                            Toast.LENGTH_LONG).show();
                    //add by yangyang2@tcl.com, fix bug 1305216 end
                } else {
                    Log.e("Kaidi", "Press Button, state: " + state);
                }
            }
        });

        windowManager.addView(mContainer, wmParams);
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.scale_in);
        mRecordView.startAnimation(anim);
    }


    private void showHintView(){
        mHintView = (RelativeLayout) mLayoutInflater.inflate(R.layout.layout_hint_info, null);
        mHintText = (TextView) mHintView.findViewById(R.id.HintText);
        mHintText.setText(getString(R.string.msg_screen_corder_operation_hint));

        wmParams = new WindowManager.LayoutParams();
        wmParams.type = LayoutParams.TYPE_TOAST;
        wmParams.format = PixelFormat.RGBA_8888;
        wmParams.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL | LayoutParams.FLAG_NOT_FOCUSABLE;

        int w = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        int h = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        mHintText.measure(w, h);
        int height = mHintText.getMeasuredHeight();
        float hintTextY = mScreenHeight/2 - height - GAP_BETWEEN_HINT_TEXT_WITH_FLOAT_VIEW;
        mHintText.setY(hintTextY);

        wmParams.gravity = Gravity.START | Gravity.TOP;
        wmParams.width = mScreenWidth;
        wmParams.height = mScreenHeight;
        wmParams.x = 0;
        wmParams.y = 0;
        windowManager.addView(mHintView, wmParams);

        mHintView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mHintView != null) {
                    windowManager.removeView(mHintView);
                    mHintView = null;
                }
            }
        });
    }

    public void updateFloatViewSize() {
        if (mContainer != null) {
            if (state != STATE_RECORDING || (SettingsUtil.usingFrontCamera(this) == false) || (isBoostAnimating == true)) {
                mContainer.updateViewSize(DEFAULT_FLOAT_VIEW_WIDTH, DEFAULT_FLOAT_VIEW_HEIGHT);
                mRecordView.setLayoutParams(new RelativeLayout.LayoutParams(DEFAULT_FLOAT_VIEW_WIDTH, DEFAULT_FLOAT_VIEW_HEIGHT));
                mRecordView.setX(0.0f);
                mRecordView.setY(0.0f);
                //mContainer.setPadding(0, 0, 0, 0);
                return;
            }

            int defaultContainerWidth = mScreenWidth/4;
            int defaultContainerHeight = mScreenWidth/4;

            int frontCaemraPreviewPreferenceVal = SettingsUtil.getFrontCameraPreviewPreferenceValue(this);

            int containerWidth = defaultContainerWidth;
            int containerHeight = defaultContainerHeight;
            int recorderViewWidth = defaultContainerWidth;
            int recorderViewHeight = defaultContainerHeight;
            float recorderViewX = 0.0f;
            float recorderViewY = 0.0f;
            if (frontCaemraPreviewPreferenceVal == SettingsUtil.SCREEN_SIZE_LARGE) {
                containerWidth = defaultContainerWidth * 2;
                containerHeight = defaultContainerHeight * 2;
                recorderViewWidth = containerWidth;
                recorderViewHeight = containerHeight;
            } else if (frontCaemraPreviewPreferenceVal == SettingsUtil.SCREEN_SIZE_FULL_SCREEN){
                containerWidth = mScreenWidth;
                containerHeight = mScreenHeight;
                recorderViewWidth = DEFAULT_FLOAT_VIEW_WIDTH;
                recorderViewHeight = DEFAULT_FLOAT_VIEW_HEIGHT;
                recorderViewX = mScreenWidth/2 - DEFAULT_FLOAT_VIEW_WIDTH / 2;
                recorderViewY = mScreenHeight - DEFAULT_FLOAT_VIEW_HEIGHT - FLOAT_VIEW_PADDING_TO_BOTTOM_FULLSCREEEN;
                mTextureView.setLayoutParams(new RelativeLayout.LayoutParams(containerWidth, containerHeight));
                mTextureView.setAlpha(1.0f);
                upateFullScreenFrameImmediately();
            }
            mContainer.updateViewSize(containerWidth, containerHeight);
            mRecordView.setLayoutParams(new RelativeLayout.LayoutParams(recorderViewWidth, recorderViewHeight));
            mRecordView.setX(recorderViewX);
            mRecordView.setY(recorderViewY);
        }
    }

    private void initCamera(SurfaceTexture texture) {
        Log.e("Kaidi", "Surface Created");

        try {
            mCamera = CameraHelper.getDefaultFrontFacingCameraInstance();
            Camera.getCameraInfo(CameraInfo.CAMERA_FACING_FRONT, mCameraInfo);
            Log.e("Kaidi", "Orientation: " + mCameraInfo.orientation);
            Parameters ps = mCamera.getParameters();
            // Use lowest fps
            List<Integer> fpsList = ps.getSupportedPreviewFrameRates();
            int fps = -1;
            for (int f : fpsList) {
                if (fps < 0 || f < fps)
                    fps = f;
            }
            if (fps > 0) {
                ps.setPreviewFrameRate(fps);
            }

            // Calculate preview size
            List<Size> list = ps.getSupportedPreviewSizes();
            int w = -1;
            int h = -1;
            for (Size size : list) {
                if ( size.width > w) {
                    w = size.width;
                    h = size.height;
                }
            }
            for (Size size : list) {//get middle preview size to blance the quality and performance
                if ( size.width < (w / 3)) {
                    w = size.width;
                    h = size.height;
                    break;
                }
            }

            // not every phone support 864 x 480, so not force to set to this value or camera will not work.
//            w = 864;		//fix the resolution the blance of preview quality and performance
//            h = 480;

            if (w > 0) {
                ps.setPreviewSize(w, h);
                previewWidth = w;
                previewHeight = h;
            }

            // camera will not work if not support FOCUS_MODE_AUTO.
            List<String> fsList = ps.getSupportedFocusModes();
            for(String fs : fsList) {
                if(fs.equals(Camera.Parameters.FOCUS_MODE_AUTO)) {
                    ps.setFocusMode(fs);
                }
            }

            mCamera.setParameters(ps);
            mCamera.setPreviewCallback(new PreviewCallback() {
                @Override
                public void onPreviewFrame(byte[] bytes, Camera camera) {
                    handlePreviewFrame(bytes);
                }
            });
            mCamera.setErrorCallback(new Camera.ErrorCallback() {
                @Override
                public void onError(int error, Camera camera) {
                    sendErrorBroadCast(USING_CAMERA_ERROR);
                }
            });
            try {
                mCamera.setPreviewTexture(texture);
                mCamera.setDisplayOrientation(270);
                mCamera.startPreview();
            } catch (Exception e) {
                //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
                Log.e("Kaidi", "Preview failed", e);
                Toast.makeText(this, R.string.error_failed_start_preview, Toast.LENGTH_LONG).show();
                sendErrorBroadCast(INIT_CAMERA_ERROR);
            }
        } catch (Exception e) {
            Log.e("Kaidi", "ScreenRecorder failed to start camera", e);
            Toast.makeText(this, R.string.error_failed_init_camera, Toast.LENGTH_LONG).show();
            sendErrorBroadCast(INIT_CAMERA_ERROR);
            //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end
        }
    }

    /**
     * Get Preview frame and display
     *
     * @param bytes
     */
    private void handlePreviewFrame(byte[] bytes) {
        if (state != STATE_RECORDING)
            return;
        if (isBoostAnimating == true)
            return;

        if (SettingsUtil.usingFrontCamera(RecordService.this)) {
            // Display preview round bitmap
            mFrameBmp = ImageUtil.fromYUV(bytes, previewWidth, previewHeight);
            int cameraPreviewPreferenceVal = SettingsUtil.getFrontCameraPreviewPreferenceValue(this);
            if (cameraPreviewPreferenceVal == 0 || cameraPreviewPreferenceVal == 1) {
                Bitmap bm = ImageUtil.crop(mFrameBmp, previewWidth, previewHeight, getRotationValue(), false);
                bm = ImageUtil.getRoundedCornerBitmap(bm, bm.getWidth() / 2);
                mRecordView.setBackgroundDrawable(new BitmapDrawable(bm));
                mContainer.setBackgroundColor(Color.TRANSPARENT);
                //mContainer.setPadding(4, 4, 4, 4);
            } else{
                //modified by yangyang2@tcl.com, fix bug 788527 begin
                try {
                    mCamera.setDisplayOrientation(getCameraDisplayOrientation());
                } catch (Exception e) {
                    Log.e("RecordService", "handlePreviewFrame() : " + e.getMessage());
                    e.printStackTrace();
                }
//                Bitmap bm = ImageUtil.crop(mFrameBmp, previewWidth, previewHeight, getRotationValue(), true);
                mRecordView.setBackgroundResource(R.drawable.ic_stop);
//                mContainer.setBackgroundDrawable(new BitmapDrawable(bm));
                //modified by yangyang2@tcl.com, fix bug 788527 end
                //mContainer.setPadding(0, 0, 0, 0);
            }
        } else {
            mRecordView.setBackgroundResource(R.drawable.ic_stop);
            mContainer.setBackgroundColor(Color.TRANSPARENT);
            //mContainer.setPadding(0, 0, 0, 0);
        }
        //removed by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
        // Display record time
//        long now = System.currentTimeMillis();
//        long recordTime = now - recordStartTime;
//        int totalSeconds = (int) recordTime / 1000;
//        int seconds = totalSeconds % 60;
//        int totalMinutes = totalSeconds / 60;
//        int minutes = totalMinutes % 60;
//        int hours = totalMinutes / 60;
//        StringBuilder sb = new StringBuilder();
//        if (hours >= 10)
//            sb.append(hours + ":");
//        else if (hours > 0)
//            sb.append("0" + hours + ":");
//        if (minutes >= 10)
//            sb.append(minutes + ":");
//        else
//            sb.append("0" + minutes + ":");
//        if (seconds >= 10)
//            sb.append(seconds);
//        else
//            sb.append("0" + seconds);
//        mRecordView.setText(sb.toString());
        //removed by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end
    }

    private int getCameraDisplayOrientation() {
        int orientation = this.getResources().getConfiguration().orientation;
        //camera default orientation. value have 270 or 90
        int cameaorientation = mCameraInfo.orientation;
        int rot = display.getRotation();
        int displayOrientation = 270;
        Log.i("handlePreview", " configuration().orientation:" + orientation + " Camera orientation:"
                + cameaorientation+ " display rotation:" + rot);
        if ( orientation == Configuration.ORIENTATION_LANDSCAPE) {
            if( cameaorientation == 270) {
                if( rot == 1){
                    displayOrientation = 0;
                } else if( rot == 3){
                    displayOrientation = 180;
                }
            } else if( cameaorientation == 90){
                if( rot == 1) {
                    displayOrientation = 180;
                } else if(rot == 3) {
                    displayOrientation = 0;
                }
            }
        } else if(orientation == Configuration.ORIENTATION_PORTRAIT) {
            if ( cameaorientation == 270){
                if(rot == 0) {
                    displayOrientation = 90;
                } else if (rot == 2){
                    displayOrientation = 270;
                }
            } else if (cameaorientation == 90) {
                if(rot == 0) {
                    displayOrientation = 270;
                } else if (rot == 2){
                    displayOrientation = 90;
                }
            }
        }
        return displayOrientation;
    }

    private void tryShareScreen() {
        if (mMediaProjection == null) {
            Intent intent = new Intent(appContext,
                    ProjectionActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            return;
        }
        //startRecord();
    }

    private void stopPreview() {
        if (mCamera != null) {
            try {
                mCamera.stopPreview();
                mCamera.release();
                mCamera = null;
            } catch (Exception e) {
                Log.e("Kaidi", "Release failed", e);
            }
        }
    }

    private void stopAndNotify() {
        state = STATE_SAVING;
        stopRecord();
        updateFloatViewSize();
        this.showForegroundNotification();
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.setPreviewCallback(null);
            mCamera.setErrorCallback(null);
            mCamera.release();
            mCamera = null;
        }
        if (mTextureView != null) {
            mTextureView.setVisibility(View.GONE);
            mContainer.removeView(mTextureView);
        }
        mContainer.setBackgroundColor(Color.TRANSPARENT);
        //mContainer.setPadding(0, 0, 0, 0);
        mRecordView.setText("");
        mRecordView.setBackgroundResource(R.drawable.gc_icon_rec);
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.scale_in);
        mRecordView.startAnimation(anim);
        state = STATE_IDLE;
        //change by yangyang2@tcl.com, fie bug 1530882 begin
        showRecordFinishNotify(true);
        //change by yangyang2@tcl.com, fie bug 1530882 end
    }

    private void showRecordFinishNotify(boolean isShowFullScreen) {
        String filename = mRecorderUtil.getFilename();
        if (filename == null)
            return;
        File file = new File(filename);
        String shortName = file.getName();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                appContext);
        builder.setSmallIcon(R.drawable.ic_recorder);
        builder.setTicker(getString(R.string.noti_finished));
        builder.setWhen(System.currentTimeMillis());
        builder.setAutoCancel(true);
        CharSequence contentTitle = getString(R.string.app_name);
        CharSequence contentText = getString(R.string.noti_finished);
        builder.setContentTitle(contentTitle);
        builder.setContentText(contentText);
        builder.setPriority(Notification.PRIORITY_MAX);
        //change by yangyang2@tcl.com, fie bug 1530882 begin
        if(isShowFullScreen) {
            Intent fullscreenIntent = new Intent();
            builder.setFullScreenIntent(PendingIntent.getBroadcast(this, 0,
                    fullscreenIntent, 0), true);
            //3 seconds later, auto cancel full screen notification
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    Log.i("Kaidi", "show notify agine");
                    if(Build.VERSION.SDK_INT <= 22) {
                        //showRecordFinishNotify(false);
                    } else {
                        StatusBarNotification[] notifications = nm.getActiveNotifications();
                        int i = 0;
                        int id = -1;
                        for (; i < notifications.length; i++) {
                            id = notifications[i].getId();
                            Log.i("Kaidi", "notificate id:" + id);
                            //if full screen notification is active, cancel it and show again
                            if (NOTI_ID_FINISH == id) {
                                showRecordFinishNotify(false);
                                break;
                            }
                        }
                    }
                }
            }, 3000);
        }
        //change by yangyang2@tcl.com, fie bug 1530882 end
        Intent viewIntent = new Intent(ACTION);
        viewIntent.putExtra(KEY_COMMAND, COMMAND_VIEW);
        viewIntent.putExtra(KEY_FILENAME, filename);
        PendingIntent viewPendingIntent = PendingIntent.getBroadcast(this, REQUEST_CODE_VIEW,
                viewIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent sharingIntent = new Intent(ACTION);
        sharingIntent.putExtra(KEY_COMMAND, COMMAND_SHARE);
        sharingIntent.putExtra(KEY_FILENAME, filename);
        PendingIntent sharePendingIntent = PendingIntent.getBroadcast(this,
                REQUEST_CODE_SHARE, sharingIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent trimIntent = new Intent(ACTION);
        trimIntent.putExtra(KEY_COMMAND, COMMAND_TRIM);
        trimIntent.putExtra(KEY_FILENAME, filename);
        PendingIntent trimPendingIntent = PendingIntent.getBroadcast(this, REQUEST_CODE_TRIM,
                trimIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        builder.setContentIntent(viewPendingIntent);
        builder.addAction(R.drawable.ic_view, null, viewPendingIntent);
        builder.addAction(R.drawable.ic_share,null, sharePendingIntent);
        builder.addAction(R.drawable.ic_cut,null, trimPendingIntent);

        Notification notification = builder.build();
        try {
            nm.cancel(NOTI_ID_FINISH);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("Kaidi", "Failed to cancel", e);
        }
        nm.notify(NOTI_ID_FINISH, notification);
    }

    //add by yangyang2@tcl.com ,fix bug 1383758 begin
    private void stopRecordWhenError() {
        state = STATE_SAVING;
        stopRecord();
        updateFloatViewSize();
        this.showForegroundNotification();
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.setPreviewCallback(null);
            mCamera.setErrorCallback(null);
            mCamera.release();
            mCamera = null;
        }
        if (mTextureView != null) {
            mTextureView.setVisibility(View.GONE);
            mContainer.removeView(mTextureView);
        }
        mContainer.setBackgroundColor(Color.TRANSPARENT);
        mRecordView.setText("");
        mRecordView.setBackgroundResource(R.drawable.gc_icon_rec);
        Animation anim = AnimationUtils.loadAnimation(this, R.anim.scale_in);
        mRecordView.startAnimation(anim);
        state = STATE_IDLE;
        String filename = mRecorderUtil.getFilename();
        if (filename == null)
            return;
        File file = new File(filename);
        if(file.exists()) {
            file.delete();
        }
    }
    //add by yangyang2@tcl.com ,fix bug 1383758 end

    private void stopRecord() {
        Log.i("Kaidi", "Stop Record");

        //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
        // stop showtouches
        ShowTouchesUtil.setShowTouches(appContext, systemEnabledTouchesState);
        stopRecordTimer();
        //when stop timer ,make sure 'mRecordView' text is null
        Message message = mHandler.getFreshTimeMessage();
        message.obj = "";
        mHandler.sendMessageDelayed(message, 990);
        //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end
        mRecorderUtil.stop(this);
        if (mVirtualDisplay != null) {
            mVirtualDisplay.release();
            mVirtualDisplay = null;
        }
        if (mMediaProjection != null) {
            mMediaProjection.stop();
            mMediaProjection = null;
        }
        mRecorderUtil.setErrorListener(null);
    }

    private void startRecord() {
        Log.i("Kaidi", "Start Record");

        //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
        if(!mRecorderUtil.initAndPrepare(appContext)){
            sendErrorBroadCast(INIT_RECORDER_ERROR);
            return;
        }
        //add by yangyang2@tcl.com , fix bug 1250919 begin
        mRecorderUtil.setErrorListener(new MediaRecorder.OnErrorListener() {
            @Override
            public void onError(MediaRecorder mr, int what, int extra) {
                Log.e("Kaidi", "recorder happen error : " + what);
                sendErrorBroadCast(USING_MEDIARECORDER_ERROR);
            }
        });
        //add by yangyang2@tcl.com , fix bug 1250919 end
        cancelStopNotification();
        Resolution res = mRecorderUtil.getRes();
        Surface surface = mRecorderUtil.getSurface();
        mVirtualDisplay = createVirtualDisplay(res, surface);
        if (mRecorderUtil.start() == false) {
            sendErrorBroadCast(START_RECORDER_ERROR);
            return;
        }
        state = STATE_RECORDING;
        recordStartTime = System.currentTimeMillis();
        // show touch
        setShowTouchesWhenStartRecord();
        updateFloatViewSize();
        this.showForegroundNotification();
        startRecordTimer();
        //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end
    }

    private VirtualDisplay createVirtualDisplay(
            Resolution res, Surface surface) {
        return mMediaProjection
                .createVirtualDisplay(
                        "RecordService",
                        res.width,
                        res.height,
                        mScreenDensity,
                        DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                        surface, null,
                        null);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void setMP(MediaProjection mp) {
        mMediaProjection = mp;
    }

    /**
     * Get Current display rotation value
     *
     * @return
     */
    public int getRotationValue() {
        int rot = display.getRotation();
        int rotation = mCameraInfo.orientation;
        return (rotation + rot * 90) % 360;
    }

    @Override
    public void onDestroy() {
        onDestorying = true;
        super.onDestroy();
        Log.e("Kaidi", "RecordService Destroy");
        mRecordView.setOnClickListener(null);
        hideFloatingView();
        this.stopForeground(true);
        finishProjectionActivity();
        closeNotification();
        SettingsUtil.setScreenRecordOn(this, false);
        if (mMediaProjection != null) {
            mMediaProjection.stop();
            mMediaProjection = null;
        }
        this.unregisterReceiver(mReceiver);
        //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
        mHandler.removeCallbacksAndMessages(this);
        //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end
    }

    public void LongPressStop(){
        //not allowed stop service when recording screen
        if(state == STATE_RECORDING){
            return;
        }
        RecordService.this.stopSelf();
    }

    /**
     * Hide floating View<br>
     * If is recording, save current recording
     */
    private void hideFloatingView() {
        //modified by yangyang2@tcl.com , fix bug 1250919 begin
//        if (mTextureView != null
//                && mTextureView.getVisibility() == View.VISIBLE
//                && state == STATE_RECORDING) {
        if(state == STATE_RECORDING) {
        //modified by yangyang2@tcl.com , fix bug 1250919 end
            try {
                stopAndNotify();
            } finally {
            }
        }
        if (mContainer != null) {
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.scale_out);
            anim.setAnimationListener(new AnimationListener() {
                @Override
                public void onAnimationEnd(Animation arg0) {
                    if (mContainer == null)
                        return;
                    try {
                        windowManager.removeView(mContainer);
                    } catch (Exception e) {
                        Log.e("Kaidi", "Failed to remove view", e);
                    }
                }

                @Override
                public void onAnimationRepeat(Animation arg0) {
                }

                @Override
                public void onAnimationStart(Animation arg0) {
                }
            });
            mRecordView.startAnimation(anim);
        }
    }
    private void prepareForRecording() {
        if (state != STATE_PENDING_RECORD) {
            return;
        }

        isBoostAnimating = true;
        mRecordView.setBackgroundResource(R.drawable.boost);
        mRecordView.setText("");
        final AnimationDrawable ad = (AnimationDrawable) mRecordView.getBackground();
        mHandler.post(new Runnable() {
            public void run() {
                ad.start();
                animStartTime = System.currentTimeMillis();
            }
        });
        mHandler.postDelayed(new Runnable() {
            public void run() {
                if (onDestorying == true) {
                    return;
                }
                isBoostAnimating = false;
                if (SettingsUtil.usingFrontCamera(RecordService.this)) {
                    initTextureView();
                } else {
                    mRecordView.setBackgroundResource(R.drawable.ic_stop);
                    mContainer.setBackgroundColor(Color.TRANSPARENT);
                }
                startRecord();
            }
        }, 1050);
    }

    private void initTextureView() {
        //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
        if(mTextureView == null) {
            mTextureView = new TextureView(getApplicationContext());
        } else {
            mTextureView.setVisibility(View.VISIBLE);
        }
        //modified by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(mScreenWidth, mScreenHeight);
        mTextureView.setAlpha(0.0f);
        params.addRule(RelativeLayout.CENTER_IN_PARENT);
        mTextureView.setLayoutParams(params);
        //add by yangyang2@tcl.com , fix bug 1401116 begin
        mContainer.removeView(mTextureView);
        //add by yangyang2@tcl.com , fix bug 1401116 end
        mContainer.addView(mTextureView);
        mContainer.removeView(mRecordView);
        mContainer.addView(mRecordView);
        mTextureView.setSurfaceTextureListener(new SurfaceTextureListener() {
            @Override
            public void onSurfaceTextureAvailable(SurfaceTexture texture, int arg1, int arg2) {
                initCamera(texture);
            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture arg0) {
                Log.e("Kaidi", "SurfaceTexture Destoryed");
                if (mCamera != null)
                    mCamera.setPreviewCallback(null);
                stopPreview();
                return false;
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture arg0, int arg1, int arg2) {
                if (arg1 == mScreenWidth && arg2 == mScreenHeight) {
                    mTextureView.setAlpha(1.0f);
                } else {
                    mTextureView.setAlpha(0.0f);
                }
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture arg0) {
            }
        });
    }

    private void upateFullScreenFrameImmediately() {
        if (mFrameBmp == null) {
            return;
        }
        Bitmap bm = ImageUtil.crop(mFrameBmp, previewWidth, previewHeight, getRotationValue(), true);

        mRecordView.setBackgroundResource(R.drawable.ic_stop);
        mContainer.setBackgroundDrawable(new BitmapDrawable(bm));
    }

    /**
     * Don't force to initial the preview size,
     * get the setting configuration from SettingsActivityClean.
     */
    private void initFrontCameraPreviewSize() {
//      SettingsUtil.setFrontCameraPreviewPreferenceValue(RecordService.this, SettingsUtil.SCREEN_SIZE_SMALL);
    }

    private void cancelStopNotification() {
        if (nm == null) {
            return;
        }
        try {
            nm.cancel(NOTI_ID_FINISH);
        } catch (Exception e) {
            Log.e("Screen-corder", "Failed to cancel", e);
        }
    }

    private void finishProjectionActivity() {
        Intent finishIntent = new Intent(ACTION);
        finishIntent.putExtra(KEY_COMMAND, COMMMAN_FINISH_PROJECTION_ACTIVITY);
        sendBroadcast(finishIntent);
    }
    //[BUGFIX]-Add by Shijian.hu, 08/19/2015,PR1063455 Begin
    private void closeNotification() {
        Intent intent = new Intent(ACTION);
        intent.setAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        sendBroadcast(intent);
    }
    //[BUGFIX]-Add by Shijian.hu, 08/19/2015,PR1063455 end
    private boolean getExclusionService(){
        ActivityManager am = (ActivityManager) this.getSystemService(this.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> myList = am.getRunningServices(150);
        if(myList.size() <= 0){
            return false;
        }
        for (int i = 0;i < myList.size(); i++){
            String nameStr = myList.get(i).service.getClassName().toString();
            if (nameStr.equals(CAMERA_DISPLAY_SERVICE_NAME) ) {
                Log.e("Screen-corder", "camera display is running.");
                Toast.makeText(RecordService.this, R.string.msg_camera_running_close_to_continue, Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        return false;
    }

    private void setShowTouchesWhenStartRecord(){
        systemEnabledTouchesState = ShowTouchesUtil.getShowTouches(appContext);
        boolean appEnabledTouchesState = SettingsUtil.getShowTouchesStatus(RecordService.this);
        if(systemEnabledTouchesState != appEnabledTouchesState){
            ShowTouchesUtil.setShowTouches(appContext, appEnabledTouchesState);
        }
    }

    private boolean getWifiDisplayRunningState() {
        DisplayManager displayManager = (DisplayManager)this.getSystemService(this.DISPLAY_SERVICE);

        Object wifiDisplayStatus = ReflectionMethod.invokeMethod(displayManager, "getWifiDisplayStatus");
        if( wifiDisplayStatus == null) {
            return false;
        }
        Integer result = (Integer)ReflectionMethod.invokeMethod(wifiDisplayStatus, "getActiveDisplayState");
        if(result == null) {
            return false;
        }
        int displayState = result.intValue();
        Log.e("YY", "Wifi status: " + displayState);
        if(displayState == ReflectionMethod.DISPLAY_STATE_CONNECTING
                || displayState == ReflectionMethod.DISPLAY_STATE_CONNECTED) {
            Toast.makeText(RecordService.this, R.string.msg_wifidisplay_running_close_to_continue, Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 begin
    private void sendErrorBroadCast(int errorType){
        Intent errorIntent = new Intent(RecordService.ACTION);
        errorIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_RECORDING_ERROR);
        errorIntent.putExtra(EXTRA_ERROR_TYPE, errorType);
        sendBroadcast(errorIntent);
    }

    private void closeCameraWhenRecording(){
        if(state == STATE_RECORDING) {
            if(mCamera != null) {
                mCamera.stopPreview();
                mCamera.setPreviewCallback(null);
                mCamera.setErrorCallback(null);
                mCamera.release();
                mCamera = null;
            }
            if(mTextureView != null) {
                mTextureView.setVisibility(View.GONE);
                mTextureView.setSurfaceTextureListener(null);
            }
            mRecordView.setBackgroundResource(R.drawable.ic_stop);
            mContainer.removeView(mTextureView);
            mContainer.setBackgroundColor(Color.TRANSPARENT);
            SettingsUtil.setFrontCamera(this, false);
            showForegroundNotification();
            updateFloatViewSize();
            Intent updateSettingsCameraStatusIntent = new Intent(RecordService.ACTION);
            updateSettingsCameraStatusIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_UPDATE_SETTINGS_STATUS_CAMERA);
            RecordService.this.sendBroadcast(updateSettingsCameraStatusIntent);
        }
    }

    public static class RecordHandler extends Handler{
        public static int MESSAGE_FRESH_TIME = 0x01;
        private RecordService mService;
        public RecordHandler(RecordService service) {
            mService = service;
        }
        @Override
        public void dispatchMessage(Message msg) {
            super.dispatchMessage(msg);
            if(msg.arg1 == MESSAGE_FRESH_TIME) {
                if(msg.obj instanceof String) {
                    mService.setRecordTime((String)msg.obj);
                }
            }
        }

        public Message getFreshTimeMessage(){
            Message message = Message.obtain();
            message.arg1 = MESSAGE_FRESH_TIME;
            return message;
        }
    }

    private void setRecordTime(String time){
        if(mRecordView != null) {
            mRecordView.setText(time);
        }
    }

    private void startRecordTimer() {
        Log.i("Kaidi", "StartTimeDisplay");
        if (mCallTimer != null) {
            mCallTimer.cancel();
        }
        mCallTimer = new Timer();
        mTask = new TimerTask() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                long duration = now - recordStartTime;
                long seconds = duration / 1000;
                int minute = (int) seconds / 60;
                int second = (int) seconds % 60;
                StringBuilder sb = new StringBuilder();
                if (minute < 10)
                    sb.append("0" + minute);
                else
                    sb.append(minute);
                sb.append(":");
                if (second < 10)
                    sb.append("0" + second);
                else
                    sb.append(second);
                String timeMsg = sb.toString();
                Log.i("Kaidi", "TimeDisplay run() " + timeMsg);
                Message message = mHandler.getFreshTimeMessage();
                message.obj = timeMsg;
                mHandler.sendMessage(message);
            }
        };
        mCallTimer.scheduleAtFixedRate(mTask, 0, 990);
    }

    private void stopRecordTimer() {
        if(mTask != null) {
            mTask.cancel();
        }
        if(mCallTimer != null) {
            mCallTimer.cancel();
        }
        mTask = null;
        mCallTimer = null;
    }
    //add by yangyang2@tcl.com , fix bug 1173825,1173942,1176574 end

    //add by yangyang2@tcl.com , fix bug 1250919 begin
    private void resetToInitialStatue(){
        if(state == STATE_RECORDING) {
            //add by yangyang2@tcl.com ,fix bug 1383758 begin
            stopRecordWhenError();
            //add by yangyang2@tcl.com ,fix bug 1383758 end
        } else {
            if(mCamera != null) {
                mCamera.stopPreview();
                mCamera.setPreviewCallback(null);
                mCamera.setErrorCallback(null);
                mCamera.release();
                mCamera = null;
            }
            if (mTextureView != null) {
                mTextureView.setVisibility(View.GONE);
                mContainer.removeView(mTextureView);
            }
            if(mVirtualDisplay != null) {
                mVirtualDisplay.release();
                mVirtualDisplay = null;
            }
            if(mMediaProjection != null) {
                mMediaProjection.stop();
                mMediaProjection = null;
            }
            mContainer.setBackgroundColor(Color.TRANSPARENT);
            mRecordView.setText("");
            mRecordView.setBackgroundResource(R.drawable.gc_icon_rec);
            Animation anim = AnimationUtils.loadAnimation(this, R.anim.scale_in);
            mRecordView.startAnimation(anim);
            state = STATE_IDLE;
            updateFloatViewSize();
            showForegroundNotification();
        }
    }
    //add by yangyang2@tcl.com , fix bug 1250919 end

}
