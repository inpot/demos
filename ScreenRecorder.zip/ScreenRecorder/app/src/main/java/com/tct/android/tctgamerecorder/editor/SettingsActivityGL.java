
package com.tct.android.tctgamerecorder.editor;

import java.io.File;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.drawable.AnimationDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.PreferenceActivity;
import android.support.v4.app.NotificationCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.tct.android.tctgamerecorder.layout.MyRelativeLayout;
import com.tct.android.tctgamerecorder.R;
import com.tct.android.tctgamerecorder.RecordService;
import com.tct.android.tctgamerecorder.util.MediaCodecUtil;
import com.tct.android.tctgamerecorder.util.RecorderUtil;
import com.tct.android.tctgamerecorder.util.RecorderUtil.Resolution;

@SuppressWarnings("deprecation")
public class SettingsActivityGL extends PreferenceActivity {

    private final static String TAG = "SettingsActivity";
    // For Preference controls
    private CheckBoxPreference statusPref;
    private CheckBoxPreference frontCameraPref;
    private ListPreference audioPref;
    private ListPreference videoSizePref;
    private ListPreference videoQualityPref;

    // For screen record
    private NotificationManager nm;
    private MediaProjectionManager mProjectionManager;
    private MediaProjection mMediaProjection;
    private final static int PERMISSION_CODE = 1;
    private RecorderUtil mRecorderUtil;
    private int mScreenDensity;
    private VirtualDisplay mVirtualDisplay;

    // For broadcast & keys
    public final static String KEY_HIDE = "com.tct.android.tctgamerecorder.key_hide";
    public final static String KEY_ACTION = "com.tct.android.tctgamerecorder.key_action";
    public final static String ACTION_START = "start";
    public final static String ACTION_STOP = "stop";
    public BroadcastReceiver mBroadcastReceiver;

    // For floating UI
    public final static int FLOAT_WIDTH = 160;
    public final static int FLOAT_HEIGHT = 160;
    private LayoutInflater mLayoutInflater;
    private WindowManager windowManager;
    private WindowManager.LayoutParams wmParams;
    private MyRelativeLayout mContainer;
    private TextView mRecordView;
    private MainView mImageView;
    private Handler mHandler;

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        mLayoutInflater = LayoutInflater.from(this);
        mHandler = new Handler();
        this.addPreferencesFromResource(R.xml.settings);
        // Find Preference objects
        statusPref = (CheckBoxPreference) this
                .findPreference(getString(R.string.key_status));
        frontCameraPref = (CheckBoxPreference) this
                .findPreference(getString(R.string.key_front_camera));
        audioPref = (ListPreference) this
                .findPreference(getString(R.string.key_audio_settings));
        videoSizePref = (ListPreference) this
                .findPreference(getString(R.string.key_video_size));
        videoQualityPref = (ListPreference) this
                .findPreference(getString(R.string.key_video_quality));

        statusPref
                .setOnPreferenceChangeListener(new OnPreferenceChangeListener() {
                    @Override
                    public boolean onPreferenceChange(Preference pref,
                            Object value) {
                        Log.i(TAG, "Status : " + value.toString());
                        if (Boolean.TRUE.equals(value)) {
                            showFloatingView();
                        } else {
                            hideFloatingView();
                        }
                        return true;
                    }
                });

        // Notify user that it will be applied to next recording
        OnPreferenceChangeListener listener = new OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference,
                    Object value) {
                Toast.makeText(SettingsActivityGL.this, R.string.msg_apply,
                        Toast.LENGTH_SHORT).show();
                return true;
            }
        };
        frontCameraPref.setOnPreferenceChangeListener(listener);
        audioPref.setOnPreferenceChangeListener(listener);
        videoSizePref.setOnPreferenceChangeListener(listener);
        videoQualityPref.setOnPreferenceChangeListener(listener);

        // Initialize media projection
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        mProjectionManager = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        mRecorderUtil = new RecorderUtil();
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        mScreenDensity = metrics.densityDpi;
        windowManager = (WindowManager) getApplicationContext()
                .getSystemService(Context.WINDOW_SERVICE);

        IntentFilter filter = new IntentFilter(KEY_ACTION);
        mBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getExtras().getString(KEY_ACTION);
                if (ACTION_START.equals(action)) {
                    tryShareScreen();
                } else if (ACTION_STOP.equals(action)) {
                    stopRecord();
                }
            }
        };
        this.registerReceiver(mBroadcastReceiver, filter);

        boolean needHide = getIntent().getBooleanExtra(KEY_HIDE, false);
        if (needHide)
            this.moveTaskToBack(true);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mMediaProjection != null) {
            mMediaProjection.stop();
            mMediaProjection = null;
        }
        this.unregisterReceiver(mBroadcastReceiver);
    }

    private void tryShareScreen() {
        if (mMediaProjection == null) {
            startActivityForResult(
                    mProjectionManager.createScreenCaptureIntent(),
                    PERMISSION_CODE);
            return;
        }
        startRecord();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != PERMISSION_CODE) {
            Log.e(TAG, "Unknown request code: " + requestCode);
            return;
        }
        if (resultCode != RESULT_OK) {
            Toast.makeText(this, "Screen Cast Permission Denied",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        mMediaProjection = mProjectionManager.getMediaProjection(resultCode,
                data);
        startRecord();
    }

    private void startRecord() {
        Log.i("Kaidi", "Start Record");
        mRecorderUtil.initAndPrepare(this);
        Resolution res = mRecorderUtil.getVideoSize(this);
        Surface surface = mRecorderUtil.getSurface();
        mVirtualDisplay = createVirtualDisplay(res, surface);
        mRecorderUtil.start();
    }

    private void stopRecord() {
        Log.i("Kaidi", "Stop Record");
        mRecorderUtil.stop(this);
        if (mVirtualDisplay == null)
            return;
        mVirtualDisplay.release();
        mVirtualDisplay = null;
    }

    private VirtualDisplay createVirtualDisplay(Resolution res, Surface surface) {
        return mMediaProjection.createVirtualDisplay("MainActivity", res.width,
                res.height, mScreenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null,
                null);
    }

    /**
     * show floating view
     */
    private void showFloatingView() {
        wmParams = new WindowManager.LayoutParams();
        wmParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        wmParams.format = PixelFormat.RGBA_8888;
        wmParams.flags = LayoutParams.FLAG_NOT_TOUCH_MODAL
                | LayoutParams.FLAG_NOT_FOCUSABLE;

        wmParams.gravity = Gravity.START | Gravity.TOP;
        wmParams.x = 0;
        wmParams.y = 0;
        wmParams.width = FLOAT_WIDTH;
        wmParams.height = FLOAT_HEIGHT;

        mContainer = (MyRelativeLayout) mLayoutInflater.inflate(
                R.layout.comp_floating_gl, null);
        mRecordView = (TextView) mContainer.findViewById(R.id.RecordView);
        // mContainer.set(windowManager, wmParams);

        mRecordView.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                tryShareScreen();

                mRecordView.setBackgroundResource(R.drawable.boost);
                mRecordView.setText("");
                AnimationDrawable ad = (AnimationDrawable) mRecordView.getBackground();
                ad.start();

                mImageView = new MainView(SettingsActivityGL.this);
                RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                        1, 1);
                params.addRule(RelativeLayout.CENTER_IN_PARENT);
                mImageView.setLayoutParams(params);
                mImageView.setOnClickListener(new OnClickListener() {
                    public void onClick(View view) {
                        stopAndNotify();
                    }
                });
                mContainer.addView(mImageView);

                // After animation, hide the animation and show the
                // GLSurfaceView
                mHandler.postDelayed(new Runnable() {
                    public void run() {
                        mRecordView.setBackgroundResource(R.drawable.gc_icon_rec);
                        mRecordView.setText(R.string.record);
                        mRecordView.setVisibility(View.GONE);

                        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mImageView
                                .getLayoutParams();
                        params.width = RelativeLayout.LayoutParams.MATCH_PARENT;
                        params.height = RelativeLayout.LayoutParams.MATCH_PARENT;
                        mImageView.setLayoutParams(params);
                    }
                }, 1800);
            }
        });

        windowManager.addView(mContainer, wmParams);
    }

    private void stopAndNotify() {
        stopRecord();
        mRecordView.setVisibility(View.VISIBLE);
        mImageView.setVisibility(View.GONE);
        mContainer.removeView(mImageView);

        String filename = mRecorderUtil.getFilename();
        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                SettingsActivityGL.this);
        builder.setSmallIcon(R.drawable.ic_launcher);
        builder.setTicker(getString(R.string.noti_finished));
        builder.setWhen(System.currentTimeMillis());
        builder.setAutoCancel(true);
        CharSequence contentTitle = getString(R.string.noti_finished);
        CharSequence contentText = getString(R.string.noti_open) + " "
                + filename;
        builder.setContentTitle(contentTitle);
        builder.setContentText(contentText);
        builder.setPriority(Notification.PRIORITY_MAX);
        Intent fullscreenIntent = new Intent();
        builder.setFullScreenIntent(PendingIntent.getBroadcast(
                SettingsActivityGL.this, 0, fullscreenIntent, 0), true);

        // Content Item to open the video
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("oneshot", 0);
        intent.putExtra("configchange", 0);
        Log.i("Kaidi", "Filename : " + filename);
        Uri uri = Uri.fromFile(new File(filename));
        intent.setDataAndType(uri, "video/*");
        PendingIntent contentIntent = PendingIntent.getActivity(
                SettingsActivityGL.this, 0, intent, 0);
        builder.setContentIntent(contentIntent);

        builder.addAction(R.drawable.ic_share,
                getString(R.string.noti_action_share), null);
        builder.addAction(R.drawable.ic_delete,
                getString(R.string.noti_action_delete), null);
        builder.addAction(R.drawable.ic_cut,
                getString(R.string.noti_action_trim), null);

        try {
            nm.cancel(1);
        } catch (Exception e) {
            Log.e("Kaidi", "Failed to cancel", e);
        }
        nm.notify(1, builder.build());
    }

    /**
     * hide floating view
     */
    private void hideFloatingView() {
        // If is recording, save the video
        if (mImageView != null && mImageView.getVisibility() == View.VISIBLE) {
            try {
                stopAndNotify();
            } finally {
            }
        }
        if (mContainer != null) {
            try {
                windowManager.removeView(mContainer);
            } catch (Exception e) {
                Log.e("Kaidi", "Failed to remove view", e);
            }
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    public static class VideoTrimActivity extends Activity {

        private Context appContext;
        private NotificationManager nm;
        private final static int NOTI_ID_FINISH = 1;
        private MediaController mController;
        public static String KEY_FILEPATH = "filepath";
        private String videoPath;
        private String mTrimedVideoPath;
        private MediaMetadataRetriever mRetriever;
        private int duration;
        // private LinearLayout mContainer;
        private VideoView mVideoView;
        private ImageView mImageView;
        private RangeSeekBar<Integer> mRangeSeekBar;
        private Button mTrimButton;
        private Button mShareButton;
    //	private Button mViewButton;
        private static int v1;
        private static int v2;
        private static int i = 0;
        private ProgressDialog mDialog = null;
        private FrameLayout layout;
        private boolean mHasPaused = false;

        private Handler mHandler = new Handler() {
            public void handleMessage(Message msg)
            {
                if (mHandler != null)
                {
                switch (msg.what) {
                case TrimMsg.PLAYING_PAUSE:
                    if (mImageView!=null) {
                        mImageView.setBackgroundResource(R.drawable.ic_pause);
                        mImageView.setVisibility(View.VISIBLE);
                    }
                    break;
                case TrimMsg.PLAYING_CONTINUE:
                    if (mImageView!=null) {
                        mImageView.setVisibility(View.GONE);
                    }
                    break;
                case TrimMsg.PLAYING_STOP:
                    if (mImageView!=null) {
                        mImageView.setBackgroundResource(R.drawable.ic_stop);
                        mImageView.setVisibility(View.VISIBLE);
                    }
                    break;
                case TrimMsg.FIRST_PALY:
                    if (mVideoView != null) {
                        mVideoView.start();
                    }
                    break;
                default:
                    break;
                }
                }
            }
        };
        @SuppressWarnings({
                "unchecked", "rawtypes"
        })
        @Override
        public void onCreate(Bundle bundle) {
            super.onCreate(bundle);
            Log.i("sysout", "onCreate");
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            this.setContentView(R.layout.layout_trimvideo);
            nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            appContext = getApplicationContext();
            // Initialize media retriever
            this.videoPath = getIntent().getStringExtra(KEY_FILEPATH);
            this.mTrimedVideoPath = this.videoPath;
            if (videoPath == null)
                finish();
            mRetriever = new MediaMetadataRetriever();
            try {
                mRetriever.setDataSource(videoPath);
                String o = mRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
                duration = Integer.parseInt(o);
                v1 = 0;
                v2 = duration;
            } catch (Exception e) {
                Log.e("Kaidi", "Failed to get media info");
            }

            // mContainer = (LinearLayout) findViewById(R.id.Container);
            layout = (FrameLayout) findViewById(R.id.TrimImageView);
            mImageView = new ImageView(VideoTrimActivity.this);
            mImageView.setVisibility(View.GONE);
            layout.addView(mImageView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

            mVideoView = (VideoView) findViewById(R.id.VideoView);
            mController = new MediaController(appContext);
            mVideoView.setVideoPath(mTrimedVideoPath);
            mVideoView.setMediaController(mController);
            mController.setMediaPlayer(mVideoView);
            mVideoView.requestFocus();
            mHandler.sendEmptyMessage(TrimMsg.FIRST_PALY);
            // mRangeSeekBar = new RangeSeekBar<Integer>(this);
            // mRangeSeekBar.setRangeValues(0, duration);
            // mContainer.addView(mRangeSeekBar);
            mRangeSeekBar = (RangeSeekBar) findViewById(R.id.RangeSeekBar);
            mRangeSeekBar.setRangeValues(0, duration);
            mTrimButton = (Button) findViewById(R.id.TrimButton);
            mShareButton = (Button) findViewById(R.id.ShareButton);
    //		mViewButton = (Button) findViewById(R.id.ViewButton);

            mRangeSeekBar.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener<Integer>() {
                @Override
                public void onRangeSeekBarValuesChanged(RangeSeekBar<?> bar, Integer minValue,
                        Integer maxValue) {
                    Log.e("Kaidi", minValue + " " + maxValue);
                    int time = 0;
                    if (v1 != minValue) {
                        time = minValue;
                    } else {
                        time = maxValue;
                    }
                    v1 = minValue;
                    v2 = maxValue;
                    Log.i("Kaidi", "Seek Time: " + time);
                    Bitmap bm = mRetriever.getFrameAtTime(time * 1000,
                            MediaMetadataRetriever.OPTION_CLOSEST);
    //                mImageView.setImageBitmap(bm);
                    resetVideo(v1);
                    mHandler.sendEmptyMessage(TrimMsg.PLAYING_CONTINUE);
                    CheckPlayProgress mCheckPlayProgress = new CheckPlayProgress(mHandler, mVideoView, v2);
                    Thread thread = new Thread(mCheckPlayProgress);
                    thread.start();
                }
            });

            mTrimButton.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    Log.i("Kaidi", "trim v1:" + v1 + " v2:" + v2);
                    if(Math.abs(v2 - v1) < 2000) {
                        Toast.makeText(VideoTrimActivity.this,
                                getString(R.string.trim_notify_time_less), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    File file = new File(videoPath);
                    String filename = file.getName();
                    int index = filename.lastIndexOf(".");
                    String nameWithoutSuffix = filename.substring(0, index);
                    String suffix = filename.substring(index);
                    File distFileObject = new File(file.getParentFile(), nameWithoutSuffix + "_trim"
                            + suffix);
                    if(distFileObject.exists()) {
                        distFileObject = new File(file.getParentFile(), nameWithoutSuffix + "_trim"
                                + System.currentTimeMillis() + suffix);
                    }
                    mTrimedVideoPath = distFileObject.getAbsolutePath();

                    new ProcessTask(videoPath, v1, v2, distFileObject.getAbsolutePath()).execute();
                }
            });

            mShareButton.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View view) {
                    File file = new File(mTrimedVideoPath);
                    Intent sharingIntent = new Intent(Intent.ACTION_SEND);
                    sharingIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    sharingIntent.setType("video/*");
                    sharingIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(file));
                    VideoTrimActivity.this.startActivity(sharingIntent);
                }
            });

    //		mViewButton.setOnClickListener(new OnClickListener() {
    //			@Override
    //			public void onClick(View view) {
    //                File file = new File(mTrimedVideoPath);
    //				Intent viewIntent = new Intent("android.intent.action.VIEW");
    //	            viewIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
    //	            viewIntent.putExtra("oneshot", 0);
    //	            viewIntent.putExtra("configchange", 0);
    //	            Uri uri = Uri.fromFile(file);
    //	            viewIntent.setDataAndType(uri, "video/*");
    //	            VideoTrimActivity.this.startActivity(viewIntent);
    //			}
    //		});

            mVideoView.setOnTouchListener(new View.OnTouchListener() {

                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    Log.i("Kaidi", "action="+event.getAction());
                    if (event.getAction() == 1) {
                        if (mVideoView.isPlaying()) {
                            Log.i("Kaidi", "暂停播放");
                            mVideoView.pause();
                            i = mVideoView.getCurrentPosition();
                            mHandler.sendEmptyMessage(TrimMsg.PLAYING_PAUSE);
                        }else {
                            if (i >= v2 || i <= v1) {
                                Log.i("Kaidi","重新播放");
                                resetVideo(v1);
                            } else {
                                Log.i("Kaidi","继续播放");
                                resetVideo(i);
                            }
                            mHandler.sendEmptyMessage(TrimMsg.PLAYING_CONTINUE);
                        }
                    }
                    CheckPlayProgress checkPlayProgress = new CheckPlayProgress(
                            mHandler, mVideoView, v2);
                    Thread thread = new Thread(checkPlayProgress);
                    thread.start();
                    return true;
                }
            });

            mVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    if (mVideoView!=null) {
                        i = v2;
                    }
                    mHandler.sendEmptyMessage(TrimMsg.PLAYING_STOP);
                }
            });

            mVideoView.setOnErrorListener(new MediaPlayer.OnErrorListener(){
                public boolean onError(MediaPlayer mp, int a, int b) {
                    Log.d("Kaidi", "Error: " + a + "," + b);
                    if (mController != null) {
                        mController.hide();
                    }
                    return true;
                }
            });

            mImageView.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (i >= v2) {
                        if (v1 > 0) {
                            i = v1;
                        } else {
                            i = 0;
                        }
                    }
                    Log.i("sysout", "i="+i+"\nv2="+v2+"\nv1="+v1);
                    resetVideo(i);
                    mHandler.sendEmptyMessage(TrimMsg.PLAYING_CONTINUE);
                }
            });

            Bitmap bm = mRetriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST);
    //        mImageView.setImageBitmap(bm);
        }

        /**
         * Destroy and release retriever
         */
        @Override
        public void onDestroy() {
            i = mVideoView.getCurrentPosition();
            Log.i("sysout", "onDestory");
            super.onDestroy();
            if (mRetriever != null) {
                mRetriever.release();
                mRetriever = null;
            }
        }

        @Override
        protected void onPause() {
            Log.i("sysout", "onPause");
            mHasPaused = true;
            mVideoView.pause();
            mHandler.sendEmptyMessage(TrimMsg.PLAYING_PAUSE);
            i = mVideoView.getCurrentPosition();
            super.onPause();
        }

        private class ProcessTask extends AsyncTask<Void, Void, String> {

            private ProgressDialog mProgressDialog;
            private String filePath;
            private long startTime;
            private long endTime;
            private String distFile;

            public ProcessTask(String filePath, long startTime, long endTime, String distFile) {
                this.filePath = filePath;
                this.startTime = startTime * 1000;
                this.endTime = endTime * 1000;
                this.distFile = distFile;
            }

            @Override
            public void onPreExecute() {
                mProgressDialog = ProgressDialog.show(VideoTrimActivity.this, "",
                        getString(R.string.msg_triming));
            }

            @Override
            public String doInBackground(Void... params)
            {
                Log.i("Kaidi", "Process start");
                try {
                    MediaCodecUtil mcu = new MediaCodecUtil();
                    mcu.trim(filePath, startTime, endTime, distFile);
                    MediaScannerConnection.scanFile(VideoTrimActivity.this, new String[]{distFile}, null,
                            new MediaScannerConnection.OnScanCompletedListener() {
                                public void onScanCompleted(String path, Uri uri) {
                                    Log.d("Screen-corder", "trimed video : Scan media database to update the gallery");
                                }
                            });
                    return "";
                } catch (Exception e) {
                    Log.e("Kaidi", "Failed to process the video", e);
                    return null;
                }
            }

            @Override
            public void onPostExecute(String result) {
                Log.i("Kaidi", "Process end");
                mProgressDialog.dismiss();
                Toast.makeText(VideoTrimActivity.this, getString(R.string.msg_trimmed_video_saved), Toast.LENGTH_SHORT).show();
            }

            private void showTrimResult() {
                File file = new File(distFile);
                String shortName = file.getName();

                NotificationCompat.Builder builder = new NotificationCompat.Builder(
                        appContext);
                builder.setSmallIcon(R.drawable.ic_recorder);
                builder.setTicker(getString(R.string.noti_finished));
                builder.setWhen(System.currentTimeMillis());
                builder.setAutoCancel(true);
                CharSequence contentTitle = getString(R.string.noti_finished);
                CharSequence contentText = getString(R.string.noti_open) + " " + shortName;
                builder.setContentTitle(contentTitle);
                builder.setContentText(contentText);
                builder.setPriority(Notification.PRIORITY_MAX);
                Intent fullscreenIntent = new Intent();
                builder.setFullScreenIntent(
                        PendingIntent.getBroadcast(appContext, 0, fullscreenIntent, 0),
                        true);

                Intent viewIntent = new Intent(RecordService.ACTION);
                viewIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_VIEW);
                viewIntent.putExtra(RecordService.KEY_FILENAME, distFile);
                PendingIntent viewPendingIntent = PendingIntent.getBroadcast(appContext,
                        RecordService.REQUEST_CODE_VIEW,
                        viewIntent, PendingIntent.FLAG_UPDATE_CURRENT);

                Intent sharingIntent = new Intent(RecordService.ACTION);
                sharingIntent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_SHARE);
                sharingIntent.putExtra(RecordService.KEY_FILENAME, distFile);
                PendingIntent sharePendingIntent = PendingIntent.getBroadcast(appContext,
                        RecordService.REQUEST_CODE_SHARE, sharingIntent,
                        PendingIntent.FLAG_UPDATE_CURRENT);

                builder.setContentIntent(viewPendingIntent);
                builder.addAction(R.drawable.ic_view, getString(R.string.noti_action_view),
                        viewPendingIntent);
                builder.addAction(R.drawable.ic_share,
                        getString(R.string.noti_action_share), sharePendingIntent);

                try {
                    nm.cancel(NOTI_ID_FINISH);
                } catch (Exception e) {
                    Log.e("Kaidi", "Failed to cancel", e);
                }
                nm.notify(NOTI_ID_FINISH, builder.build());
            }
        }

        private void resetVideo(int v){
            if (mVideoView != null) {
                if(mVideoView.isPlaying()){
                    mVideoView.pause();
                }
                mVideoView.seekTo(v);
                mVideoView.start();
            }
        }


        public static class CheckPlayProgress implements Runnable{
            private VideoView mVideoView;
            private int stop;
            private Handler mHandler;
            public void run() {
                if(mVideoView!=null){
                    while(mVideoView.isPlaying()){
                        if(mVideoView.getCurrentPosition() >= stop){
                            mVideoView.pause();
                            mHandler.sendEmptyMessage(TrimMsg.PLAYING_PAUSE);
                        }
                    }
                }
            }
            public CheckPlayProgress(Handler mHandler,VideoView mVideoView,int stop) {
                this.mVideoView = mVideoView;
                this.stop = stop;
                this.mHandler = mHandler;
            }
        }

        public interface TrimMsg{
            /**
             * 基数
             */
            final int BASE = 0x20000000;

            final int PLAYING_PAUSE = BASE +1;
            final int PLAYING_CONTINUE = BASE +2;
            final int PLAYING_STOP = BASE +3;
            final int FIRST_PALY = BASE + 4;
        }
    }
}
