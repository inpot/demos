
package com.tct.android.tctgamerecorder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.PreferenceActivity;
import android.preference.SwitchPreference;

import com.tct.android.tctgamerecorder.util.SettingsUtil;

@SuppressWarnings("deprecation")
public class SettingsActivityClean extends PreferenceActivity {

    // For Preference controls
    private SwitchPreference frontCameraPref;
    private ListPreference frontCameraPreviewsizePref;
    private SwitchPreference showTouchesPref;

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String command = intent.getStringExtra(RecordService.KEY_COMMAND);
            if (RecordService.COMMAND_UPDATE_SETTINGS_STATUS_CAMERA.equals(command)) {
                frontCameraPref.setChecked(SettingsUtil.usingFrontCamera(SettingsActivityClean.this));            
            } else if (RecordService.COMMAND_UPDATE_SETTINGS_STATUS_PREVIEWSIZE.equals(command)){
                int prefrenceVal = SettingsUtil.getFrontCameraPreviewPreferenceValue(SettingsActivityClean.this);
                frontCameraPreviewsizePref.setValueIndex(prefrenceVal);
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        int prefrenceVal = SettingsUtil.getFrontCameraPreviewPreferenceValue(SettingsActivityClean.this);
        frontCameraPreviewsizePref.setValueIndex(prefrenceVal);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.addPreferencesFromResource(R.xml.settings);
        frontCameraPref = (SwitchPreference) this
                .findPreference(getString(R.string.key_front_camera));
        frontCameraPreviewsizePref = (ListPreference) this
                .findPreference(getString(R.string.key_front_camera_preview_size));
        showTouchesPref = (SwitchPreference)this
                .findPreference(getString(R.string.key_preference_showtouches));

        // Notify user that it will be applied to next recording
        OnPreferenceChangeListener listener = new OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object value) {
                if (preference == frontCameraPreviewsizePref) {
                    Intent intent = new Intent(RecordService.ACTION);
                    intent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_PREVIEW_SIZE);
                    sendBroadcast(intent);
                } else if (preference == frontCameraPref) {
                    Intent intent = new Intent(RecordService.ACTION);
                    intent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_CAMERA);
                    sendBroadcast(intent);
                } else if(preference == showTouchesPref) {
                    Intent intent = new Intent(RecordService.ACTION);
                    intent.putExtra(RecordService.KEY_COMMAND, RecordService.COMMAND_SHOWTOUCHES_STATE_CHANGE);
                    sendBroadcast(intent);
                }
                return true;
            }
        };
        frontCameraPref.setOnPreferenceChangeListener(listener);
        frontCameraPreviewsizePref.setOnPreferenceChangeListener(listener);
        showTouchesPref.setOnPreferenceChangeListener(listener);

        IntentFilter filter = new IntentFilter(RecordService.ACTION);
        this.registerReceiver(mReceiver, filter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        this.unregisterReceiver(mReceiver);
    }
}
