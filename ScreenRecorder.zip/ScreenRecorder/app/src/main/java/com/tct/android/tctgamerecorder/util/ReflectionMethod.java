package com.tct.android.tctgamerecorder.util;

import android.util.Log;

import java.lang.reflect.Method;

/**
 * Created by yang.yang on 2015/10/23.
 */
public class ReflectionMethod {

    /**
     * Variable wifi display
     */
    public static final int DISPLAY_STATE_NOT_CONNECTED = 0;
    public static final int DISPLAY_STATE_CONNECTING = 1;
    public static final int DISPLAY_STATE_CONNECTED = 2;

    /**
     * Invoke method by Java reflection
     *
     * @param object     object to invoke
     * @param methodName methodName of object to invode
     * @param params     value to return
     */
    public static Object invokeMethod(Object object, String methodName, Object... params) {
        try {
            Class<?> clazz = object.getClass();
            Method method = findMethodByName(clazz, methodName);
            if (method == null) {
                Log.e("YY", "Failed to find method: " + methodName);
                return null;
            }
            return method.invoke(object, params);
        } catch (Exception e) {
            Log.e("YY", "Failed to invoke method: " + methodName, e);
            return null;
        }
    }

    /**
     * Get method by methodName<br>
     * It will not check the parameter type<br>
     * So please make sure that method with specific name is identical<br>
     *
     * @param clazz      which class
     * @param methodName the method name of clazz
     * @return if method exists, return method, otherwise return null
     */
    private static Method findMethodByName(Class<?> clazz, String methodName) {
        try {
            Method[] ms = clazz.getDeclaredMethods();
            for (Method method : ms) {
                if (method.getName().equals(methodName))
                    return method;
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }
}
