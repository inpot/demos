
package com.tct.android.tctgamerecorder.util;

import java.io.ByteArrayOutputStream;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ImageFormat;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.YuvImage;

public class ImageUtil {

    public static Bitmap fromYUV(byte[] data, int width, int height) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        YuvImage yuvImage = new YuvImage(data, ImageFormat.NV21, width, height, null);
        yuvImage.compressToJpeg(new Rect(0, 0, width, height), 30, out);
        byte[] imageBytes = out.toByteArray();
        Bitmap image = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
        return image;
    }

    public static Bitmap crop(Bitmap source, int width, int height, int rotation, boolean fullscreen ) {
        int edge = Math.min(width, height);
        Matrix matrix = new Matrix();
        // TODO, must check current rotation
        // matrix.postRotate(-90);
        matrix.preRotate(rotation);
        matrix.postScale(-1, 1);

		if (fullscreen) {
			return Bitmap.createBitmap(source, 0, 0, width, height, matrix, true);
		}
		
		if (width > height) {
        	return Bitmap.createBitmap(source, (width - edge) / 2, 0, edge, edge, matrix, true);
        } else {
            return Bitmap.createBitmap(source, 0, (height - edge) / 2, edge, edge, matrix, true);
        }
    }

    public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
        Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap
                .getHeight(), Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        final RectF rectF = new RectF(rect);
        final float roundPx = pixels;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }
}
